from .BodyPose_pb2 import BodyPose_Request as BodyPoseRequest, BodyPose_Response as BodyPoseResponse

__all__ = [
    'BodyPoseRequest',
    'BodyPoseResponse'
]
