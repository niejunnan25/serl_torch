from .Duration_pb2 import Duration
from .Time_pb2 import Time

__all__ = [
    'Duration',
    'Time'
]
