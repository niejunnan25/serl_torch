# 添加proto文件路径到Python路径
import os
import sys
_proto_path = os.path.join(os.path.dirname(__file__), 'proto')
if _proto_path not in sys.path:
    sys.path.insert(0, _proto_path)