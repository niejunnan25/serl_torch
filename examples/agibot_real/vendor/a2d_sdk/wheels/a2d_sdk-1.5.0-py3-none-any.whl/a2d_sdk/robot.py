#! /usr/bin/env python3
# -*- coding: utf-8 -*-
import threading
import numpy as np
from copy import deepcopy
from cosine_bus.agibotdds_py3 import agibotdds

from std_msgs_pb.msg.Header_pb2 import Header
from std_srvs_pb.srv.SetBool_pb2 import SetBool_Request as SetBoolRequest, SetBool_Response as SetBoolResponse
from std_srvs_pb.srv.Trigger_pb2 import Trigger_Request as TriggerRequest, Trigger_Response as TriggerResponse
from sensor_msgs_pb.msg.JointState_pb2 import JointState
from geometry_msgs_pb.msg.TwistStamped_pb2 import TwistStamped
from geometry_msgs_pb.msg.Pose_pb2 import Pose
from genie_msgs_pb.msg.WaistState_pb2 import WaistState
from genie_msgs_pb.msg.ArmState_pb2 import ArmState
from genie_msgs_pb.msg.ModelPredict_pb2 import ModelPredict
from genie_msgs_pb.srv.BodyPose_pb2 import BodyPose_Request as BodyPoseRequest, BodyPose_Response as BodyPoseResponse
from genie_msgs_pb.msg.HeadState_pb2 import HeadState
from genie_msgs_pb.msg.WholeBodyStatus_pb2 import WholeBodyStatus

from genie_msgs_pb.msg.RetargetInfo_pb2 import RetargetInfo
from genie_msgs_pb.msg.ReactiveControl_pb2 import ReactiveControl
from genie_msgs_pb.msg.TrajectoryTrackingControl_pb2 import TrajectoryTrackingControl
from genie_msgs_pb.msg.RetargetInfoArray_pb2 import RetargetInfoArray
from genie_msgs_pb.msg.MotorState_pb2 import MotorState
from genie_msgs_pb.msg.EndState_pb2 import EndState

import enum
import numpy as np
import time
import sys
import os
import ruckig

current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(os.path.dirname(current_dir))

from a2d_sdk.core.camera.camera_receiver_cosine import CameraReceiverCosine
from a2d_sdk.core.motion_control.motion_control import MotionController
from a2d_sdk.core.slam.slam_core import SlamCore
from a2d_sdk.utils.sdk_logger import hal_logger
from a2d_sdk.utils.buffer import GenericBuffer


from scipy.spatial.transform import Rotation as R

class CosineCamera:
    def __init__(self, camera_group: list[str]):
        self.camera_group = camera_group
        self.receiver = CameraReceiverCosine(camera_group)

    def get_latest_image(self, camera_name: str) -> np.ndarray:
        return self.receiver.get_latest_image(camera_name)

    def get_latest_packet(self, camera_name: str):
        return self.receiver.get_latest_packet(camera_name)

    def get_fps(self, camera_name: str):
        return self.receiver.get_fps(camera_name)

    def get_latency_stats(self, camera_name: str, window_seconds: float = 5.0):
        return self.receiver.get_latency_stats(camera_name, window_seconds)

    def get_image_nearest(self, camera_name: str, timestamp_ns: int) -> np.ndarray:
        """获取指定时间戳最近的图像
        
        Args:
            camera_name: 相机名称
            timestamp_ns: 时间戳(纳秒)
            
        Returns:
            np.ndarray: 图像数据,如果没有收到有效数据则返回None
        """
        return self.receiver.get_image_nearest(camera_name, timestamp_ns)

    def get_packet_nearest(self, camera_name: str, timestamp_ns: int):
        """获取指定时间戳最近的图像包
        
        Args:
            camera_name: 相机名称
            timestamp_ns: 时间戳(纳秒)
            
        Returns:
            cosine_bus.Packet: 图像包,如果没有收到有效数据则返回None
        """
        return self.receiver.get_packet_nearest(camera_name, timestamp_ns)
    
    def get_image_shape(self, camera_name: str):
        return self.receiver.get_image_shape(camera_name)

    def close(self):
        self.receiver.close()

class RobotController:
    def __init__(self):
        """
        初始化机器人控制器
        RobotController 提供了对机器人运动控制的接口，
        透传底层的运动控制功能
        """
        
        # 初始化运动控制器
        self._motion_controller = MotionController()
    
    def get_motion_status(self, timestamp=None):
        """获取运动控制状态
        
        Args:
            timestamp: 可选的时间戳(纳秒)，如果提供则返回最接近该时间戳的状态
                      如果不提供则返回最新状态
                      
        Returns:
            包含运控状态信息的字典，如果没有状态则返回None
        """
        return self._motion_controller.get_motion_control_status(timestamp)
    
    def reactive_control(self, robot_action, robot_link="base_link", lifetime=0.5):
        """创建反应式控制命令
        
        Args:
            robot_action: 控制动作字典
            robot_link: 机器人链接名称
            lifetime: 命令生命周期(秒)
            
        Returns:
            ReactiveControl消息
        """
        self._motion_controller.create_reactive_control(
            robot_action, robot_link, lifetime
        )
    
    def trajectory_tracking_control(self, infer_timestamp, robot_states, robot_actions, 
                                  robot_link="base_link", trajectory_reference_time=1.0):
        """创建轨迹跟踪控制命令
        
        Args:
            infer_timestamp: Timestamp in nanoseconds
            robot_states: robot joint states by group when infer_timestamp
            robot_actions: List of action dictionaries for trajectory
                - robot_action['part']['action_data']
                - robot_action['part']['control_type']
            robot_link: Link name of the robot
            trajectory_reference_time: Reference time for trajectory
            
        Returns:
            TrajectoryTrackingControl消息
        """
        self._motion_controller.create_trajectory_tracking(
            infer_timestamp, robot_states, robot_actions, 
            robot_link, trajectory_reference_time
        )

    def set_motion_stop(self):
        self._motion_controller.set_motion_stop()

    def set_motion_control_mode(self, mode):
        self._motion_controller.set_motion_control_mode(mode)

    def set_end_effector_pose_control(self, lifetime, control_group, left_pose=None, right_pose=None):
        self._motion_controller.set_end_effector_pose_control(lifetime, control_group, left_pose, right_pose)

    def set_joint_position_control(self, lifetime, joint_group):
        self._motion_controller.set_joint_position_control(lifetime, joint_group)
        
class Slam():
    def __init__(self):
        self._slam = SlamCore()
    
    def switch_nav_mode(self, mode):
        return self._slam.switch_nav_mode(mode)
    
    def mapping_control(self, control_code, save_map=False, map_name="default"):
        return self._slam.mapping_control(control_code, save_map, map_name)
    
    def get_map(self, map_id):
        return self._slam.get_map(map_id)
    
    def get_map_list(self):
        return self._slam.get_map_list()

    def delete_map(self, map_id):
        return self._slam.delete_map(map_id)
    
    def switch_map(self, map_id):
        return self._slam.switch_map(map_id)

    def navigate_to_pose(self, x, y, theta):
        return self._slam.navigate_to_pose(x, y, theta)
    
    def move_to_relative(self, x, y, theta):
        return self._slam.move_to_relative(x, y, theta)
    
    def relocation(self, x, y, theta):
        return self._slam.relocation(x, y, theta)
    
    def set_agv_col_level(self, level):
        return self._slam.set_agv_col_level(level)
    
    def set_agv_col_ctrl(self, ctrl=False):
        return self._slam.set_agv_col_ctrl(ctrl)
    
    def set_arm_col_level(self, level):
        return self._slam.set_arm_col_level(level)
    
    def get_arm_col_level(self):
        return self._slam.get_arm_col_level()
    
    def get_latest_map(self):
        return self._slam.get_latest_map()
    
    def pause_walk(self, pause=False):
        return self._slam.pause_walk(pause)
    
    def set_chassis_info(self, max_linear_speed, max_angular_speed, min_collision_distance):
        return self._slam.set_chassis_info(max_linear_speed, max_angular_speed, min_collision_distance)

    def get_chassis_info(self):
        return self._slam.get_chassis_info()
    
    def get_chassis_position(self):
        return self._slam.get_chassis_position()
    
    def get_chassis_battery_status(self):
        return self._slam.get_chassis_battery_status()

class RobotDds():
    def __init__(self,
                 arm_topic='/hal/arm_joint_state',
                 arm_cmd_topic='/wbc/arm_command',
                 left_arm_force_topic='/hal/left_arm_data',
                 right_arm_force_topic='/hal/right_arm_data',
                 left_ee_data_topic='/hal/left_ee_data',
                 left_ee_cmd_topic='/wbc/left_ee_command',
                 right_ee_data_topic='/hal/right_ee_data',
                 right_ee_cmd_topic='/wbc/right_ee_command',
                 head_topic='/hal/neck_state',
                 head_cmd_topic='/wbc/head_command',
                 waist_topic='/hal/waist_state',
                 waist_cmd_topic='/wbc/waist_command',
                 wheel_cmd_topic='/mbc/wheel_command',
                 fault_clear_topic='/hal/fault_clear',
                 whole_body_status_topic='/hal/whole_body_status'):
        self.node_ = agibotdds.Node("A2DRosRobot")
        self.qos = agibotdds.qos(depth=500)
        self.lock = threading.Lock()

        self._left_end_status = 'default'
        self._right_end_status = 'default'
        
        self.head_joint_names = [
            'joint_head_yaw', 'joint_head_pitch'
        ]
        self.waist_joint_names = [
            'joint_body_pitch', 'joint_lift_body'
        ]

        self._body_pose_joint_states = [None, None, None, None]
        self.arm_joint_names = [
            'Joint1_l', 'Joint2_l', 'Joint3_l', 'Joint4_l', 'Joint5_l', 'Joint6_l', 'Joint7_l',
            'Joint1_r', 'Joint2_r', 'Joint3_r', 'Joint4_r', 'Joint5_r', 'Joint6_r', 'Joint7_r'
        ]

        self.waist_initial_joint_position = [0.523, 0.279]
        self.head_initial_joint_position = [0.000, 0.506]
        self.arm_initial_joint_position = [
            0.881, 0.671, -0.5369, -1.8702, 0.8555, 0.6907, 1.1398,
            -0.881, -0.671, 0.5369, 1.8702, -0.8555, -0.6907, -1.1398
        ]
        self.hand_initial_joint_position = [
            0.881, 0.671, -0.5369, -1.8702, 0.8555, 0.6907, 
            -0.881, -0.671, 0.5369, 1.8702, -0.8555, -0.6907,
        ]
        self._arm_force_states = [
            0, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 0, 0
        ]

        self._arm_state = [None, None]
        self._last_arm_state = [None, None] # for delta calculation


        self._arm_joint_states = JointState()
        self._arm_joint_states.name.extend(self.arm_joint_names)

        self._left_ee_states = EndState()
        self._right_ee_states = EndState()

        self._waist_command = JointState()
        self._waist_command.name.extend([
            'joint_body_pitch', 'joint_lift_body'
        ])
        self._waist_joint_state = WaistState()
        self._waist_joint_state.name.extend([
            'joint_body_pitch', 'joint_lift_body'
        ])

        self._head_joint_state = HeadState()
        self._head_joint_state.name.extend([
            'joint_head_yaw', 'joint_head_pitch'
        ])
        self._gripper2hand_config = {
                "thumb_flex": {"min": 3500.0, "max": 250.0},
                "index_flex": {"min": 17000.0,"max": 10000.0},
                "middle_flex": {"min": 17000.0,"max": 10000.0},
                "ring_flex": {"min": 17000.0,"max": 10000.0},
                "little_flex": {"min": 17000.0,"max": 10000.0},
                "thumb_rot": 4000.0
            }
        
        self._arm_subscriber = self.node_.create_subscriber(
            arm_topic, JointState, self.qos, self.arm_joint_state_callback
        )
        self._arm_buffer = GenericBuffer(capacity=500)
        self._arm_cmd_publisher = self.node_.create_publisher(
            arm_cmd_topic, JointState, self.qos
        )

        self._left_arm_force_subscriber = self.node_.create_subscriber(
            left_arm_force_topic, ArmState, self.qos, self.left_arm_force_callback
        )
        self._left_arm_force_buffer = GenericBuffer(capacity=500)

        self._right_arm_force_subscriber = self.node_.create_subscriber(
            right_arm_force_topic, ArmState, self.qos, self.right_arm_force_callback
        )
        self._right_arm_force_buffer = GenericBuffer(capacity=500)
        
        self._left_ee_subscriber = self.node_.create_subscriber(
            left_ee_data_topic, EndState, self.qos, self.left_ee_data_callback
        )
        self._left_ee_buffer = GenericBuffer(capacity=500)
        self._left_ee_cmd_publisher = self.node_.create_publisher(
            left_ee_cmd_topic, JointState, self.qos
        )
        
        self._right_ee_subscriber = self.node_.create_subscriber(
            right_ee_data_topic, EndState, self.qos, self.right_ee_data_callback
        )
        self._right_ee_buffer = GenericBuffer(capacity=500)
        self._right_ee_cmd_publisher = self.node_.create_publisher(
            right_ee_cmd_topic, JointState, self.qos
        )
        
        self._head_subscriber = self.node_.create_subscriber(
            head_topic, HeadState, self.qos, self.head_joint_state_callback
        )
        self._head_buffer = GenericBuffer(capacity=500)
        self._head_cmd_publisher = self.node_.create_publisher(
            head_cmd_topic, JointState, self.qos
        )

        self._waist_subscriber = self.node_.create_subscriber(
            waist_topic, WaistState, self.qos, self.waist_joint_state_callback
        )
        self._waist_buffer = GenericBuffer(capacity=500)
        self._waist_cmd_publisher = self.node_.create_publisher(
            waist_cmd_topic, JointState, self.qos
        )

        self._wheel_cmd_publisher = self.node_.create_publisher(
            wheel_cmd_topic, TwistStamped, self.qos
        )

        self._body_pose_client = self.node_.create_client(
            '/wbc/body_pose', BodyPoseRequest, BodyPoseResponse
        )

        self._fault_clear_client = self.node_.create_client(
            fault_clear_topic, TriggerRequest, TriggerResponse
        )
        
        self._whole_body_status = WholeBodyStatus()
        self._whole_body_status_subscriber = self.node_.create_subscriber(
            whole_body_status_topic, WholeBodyStatus, self.qos, self.whole_body_status_callback
        )

    def head_joint_state_callback(self, msg):
        del self._head_joint_state.motor_states[:]
        self._head_joint_state.motor_states.extend(msg.motor_states)
        self._body_pose_joint_states[0] = msg.motor_states[0].position * 180 / np.pi
        self._body_pose_joint_states[1] = msg.motor_states[1].position * 180 / np.pi
        self._head_buffer.write(self._body_pose_joint_states[:2], timestamp=int(msg.header.stamp.sec * 1e9 + msg.header.stamp.nanosec))

    def head_joint_states_nearest(self, timestamp_ns):
        return self._head_buffer.read_nearest(timestamp_ns)
    
    def arm_joint_states_nearest(self, timestamp_ns):
        return self._arm_buffer.read_nearest(timestamp_ns)
    
    def waist_joint_states_nearest(self, timestamp_ns):
        return self._waist_buffer.read_nearest(timestamp_ns)
    
    def gripper_joint_states_nearest(self, timestamp_ns):
        if self._left_end_status != 'gripper' or self._right_end_status != 'gripper':
            return [None, None], None
        
        left_ee_data, left_ee_timestamp = self._left_ee_buffer.read_nearest(timestamp_ns)
        right_ee_data, right_ee_timestamp = self._right_ee_buffer.read_nearest(timestamp_ns)
        if left_ee_data is None or right_ee_data is None:
            return [None, None], None
        
        pos_list=[]
        pos_list.append(left_ee_data[0].position)
        pos_list.append(right_ee_data[0].position)
        
        return pos_list, left_ee_timestamp
        
    def waist_joint_state_callback(self, msg):
        del self._waist_joint_state.motor_states[:]
        self._waist_joint_state.motor_states.extend(msg.motor_states)
        for i in range(len(msg.motor_states)):
            if msg.name[i] == "joint_body_pitch":
                self._body_pose_joint_states[2] = msg.motor_states[i].position
            elif msg.name[i] == "joint_lift_body":
                self._body_pose_joint_states[3] = msg.motor_states[i].position
        self._waist_buffer.write(self._body_pose_joint_states[2:4], timestamp=int(msg.header.stamp.sec * 1e9 + msg.header.stamp.nanosec))
        if len(msg.motor_states) < 2:
            hal_logger.warning(f"Waist has less than 2 motors, {msg}")

    def arm_joint_state_callback(self, msg):
        self._arm_joint_states.position[:] = []
        self._arm_joint_states.velocity[:] = []
        self._arm_joint_states.effort[:] = []
        self._arm_joint_states.position.extend(msg.position)
        self._arm_joint_states.velocity.extend(msg.velocity)
        self._arm_joint_states.effort.extend(msg.effort)
        self._arm_joint_states.header.stamp.sec = msg.header.stamp.sec
        self._arm_joint_states.header.stamp.nanosec = msg.header.stamp.nanosec
        self._arm_buffer.write(list(msg.position), timestamp=int(msg.header.stamp.sec * 1e9 + msg.header.stamp.nanosec))
    
    def left_arm_force_callback(self, msg):
        with self.lock:
            self._arm_force_states[0:6] = msg.force_data
            self._last_arm_state[0] = self._arm_state[0]
            self._arm_state[0] = msg
            self._left_arm_force_buffer.write(self._arm_force_states[:6], timestamp=int(msg.header.stamp.sec * 1e9 + msg.header.stamp.nanosec))
    
    def right_arm_force_callback(self, msg):
        with self.lock:
            self._arm_force_states[6:12] = msg.force_data
            self._last_arm_state[1] = self._arm_state[1]
            self._arm_state[1] = msg
            self._right_arm_force_buffer.write(self._arm_force_states[6:12], timestamp=int(msg.header.stamp.sec * 1e9 + msg.header.stamp.nanosec))
    
    def left_ee_data_callback(self, msg):
        left_ee_states = EndState()
        left_ee_states.type = msg.type
        left_ee_states.name.extend(msg.name)
        left_ee_states.controlled = msg.controlled
        left_ee_states.end_state.extend(msg.end_state)
        left_ee_states.header.stamp.sec = msg.header.stamp.sec
        left_ee_states.header.stamp.nanosec = msg.header.stamp.nanosec
        
        if left_ee_states.type == 1:
            self._left_end_status = 'hand'
        elif left_ee_states.type == 2:
            self._left_end_status = 'gripper'
        else:
            self._left_end_status = 'default'

        self._left_ee_states = left_ee_states

        self._left_ee_buffer.write(list(msg.end_state), timestamp=int(msg.header.stamp.sec * 1e9 + msg.header.stamp.nanosec))

    def right_ee_data_callback(self, msg):
        right_ee_states = EndState()
        right_ee_states.type = msg.type
        right_ee_states.name.extend(msg.name)
        right_ee_states.controlled = msg.controlled
        right_ee_states.end_state.extend(msg.end_state)
        right_ee_states.header.stamp.sec = msg.header.stamp.sec
        right_ee_states.header.stamp.nanosec = msg.header.stamp.nanosec
        
        if right_ee_states.type == 1:
            self._right_end_status = 'hand'
        elif right_ee_states.type == 2:
            self._right_end_status = 'gripper'
        else:
            self._right_end_status = 'default'

        self._right_ee_states = right_ee_states

        self._right_ee_buffer.write(list(msg.end_state), timestamp=int(msg.header.stamp.sec * 1e9 + msg.header.stamp.nanosec))
    
    def body_pose_joint_states(self):
        return self._body_pose_joint_states

    def head_joint_states(self):
        return self._body_pose_joint_states[:2], self._head_joint_state.header.stamp.sec * 1e9 + self._head_joint_state.header.stamp.nanosec

    def waist_joint_states(self):
        return self._body_pose_joint_states[2:4], self._waist_joint_state.header.stamp.sec * 1e9 + self._waist_joint_state.header.stamp.nanosec

    def arm_joint_states(self):
        return self._arm_joint_states.position, self._arm_joint_states.header.stamp.sec * 1e9 + self._arm_joint_states.header.stamp.nanosec

    def gripper_states(self):
        if self._left_end_status != 'gripper' or self._right_end_status != 'gripper':
            return [None, None], None
        
        if self._left_ee_states is None or self._right_ee_states is None:
            return [None, None], None
        
        pos_list=[]
        pos_list.append(self._left_ee_states.end_state[0].position)
        pos_list.append(self._right_ee_states.end_state[0].position)
        
        return pos_list, self._left_ee_states.header.stamp.sec * 1e9 + self._left_ee_states.header.stamp.nanosec


    def hand_joint_states(self):
        # return None list(size 12) and None timestamp
        if self._left_end_status != 'hand' or self._right_end_status != 'hand':
            return [None] * 12, None
        
        if self._left_ee_states is None or self._right_ee_states is None:
            return [None] * 12, None
        
        left_ee_pos = []
        for i in range(len(self._left_ee_states.end_state)):
            left_ee_pos.append(self._left_ee_states.end_state[i].position)

        right_ee_pos = []
        for i in range(len(self._right_ee_states.end_state)):
            right_ee_pos.append(self._right_ee_states.end_state[i].position)

        return left_ee_pos + right_ee_pos, self._left_ee_states.header.stamp.sec * 1e9 + self._left_ee_states.header.stamp.nanosec
    
    def hand_joint_states_nearest(self, timestamp_ns):
        if self._left_end_status != 'hand' or self._right_end_status != 'hand':
            return [None] * 12, None
        
        if self._left_ee_states is None or self._right_ee_states is None:
            return [None] * 12, None
        
        left_ee_nearest_states, left_ee_timestamp = self._left_ee_buffer.read_nearest(timestamp_ns)
        left_ee_pos = []
        for i in range(len(left_ee_nearest_states)):
            left_ee_pos.append(left_ee_nearest_states[i].position)

        right_ee_nearest_states, right_ee_timestamp = self._right_ee_buffer.read_nearest(timestamp_ns)
        right_ee_pos = []
        for i in range(len(right_ee_nearest_states)):
            right_ee_pos.append(right_ee_nearest_states[i].position)

        return left_ee_pos + right_ee_pos, left_ee_timestamp


    def hand_force_states(self):
        return self._arm_force_states
    
    def arm_state(self):
        with self.lock:
            last_arm_state_msg = deepcopy(self._last_arm_state)
            arm_state_msg = deepcopy(self._arm_state)
        if arm_state_msg[0] is None or arm_state_msg[1] is None:
            return None

        arm_state = {}
        arm_state['joint_states'] = [motro_states.position for motro_states in arm_state_msg[0].motor_states] + [motro_states.position for motro_states in arm_state_msg[1].motor_states]
        arm_state['joint_velocity'] = [motor_states.velocity for motor_states in arm_state_msg[0].motor_states] + [motor_states.velocity for motor_states in arm_state_msg[1].motor_states]
        arm_state['timestamp'] = arm_state_msg[0].header.stamp.sec * 1e9 + arm_state_msg[0].header.stamp.nanosec


        if last_arm_state_msg[0] is not None and last_arm_state_msg[1] is not None:
            last_joint_velocity = [motor_states.velocity for motor_states in last_arm_state_msg[0].motor_states] \
                + [motor_states.velocity for motor_states in last_arm_state_msg[1].motor_states]
            delta_time = (arm_state_msg[0].header.stamp.sec * 1e9 + arm_state_msg[0].header.stamp.nanosec - last_arm_state_msg[0].header.stamp.sec * 1e9 \
                          - last_arm_state_msg[0].header.stamp.nanosec) / 1e9
            assert delta_time > 0, f"delta_time is {delta_time}"
            arm_state['joint_acceleration'] = [(arm_state['joint_velocity'][i] - last_joint_velocity[i]) / delta_time for i in range(14)]
        else:
            arm_state['joint_acceleration'] = [0.0] * 14
        
        return arm_state

    def move_wheel(self, linear, angular):
        ts = TwistStamped()
        ts.twist.linear.x = linear
        ts.twist.angular.z = angular
        # hal_logger.info(f"Move Wheel: {ts}")
        self._wheel_cmd_publisher.publish(ts)

    def linear_map(self, x, in_min, in_max, out_min, out_max):
        return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min
    
    def angle2radian(self, angle):
        return angle * np.pi / 180

    def get_hand_positions(self, controller, is_left):
        positions = []

        # 拇指弯曲
        thumb_config = self._gripper2hand_config['thumb_flex']
        pre_position = self.linear_map(
            controller,
            0.0,
            1.0,
            thumb_config['min'],
            thumb_config['max']
        ) / 100.0
        positions.append(self.angle2radian(pre_position))

        # 其他手指
        for finger in ['index_flex', 'middle_flex', 'ring_flex', 'little_flex']:
            finger_config = self._gripper2hand_config[finger]
            pre_position = self.linear_map(
                controller,
                0.0,
                1.0,
                finger_config['min'],
                finger_config['max']
            ) / 100.0
            positions.append(self.angle2radian(pre_position))

        # 拇指旋转
        pre_position = float(self._gripper2hand_config['thumb_rot']) / 100.0
        positions.append(self.angle2radian(pre_position))

        return positions

    def move_hand_as_gripper(self, positions):
        gripper_left = positions[0]
        gripper_right = positions[1]
        position_left = self.get_hand_positions(gripper_left, True)
        position_right = self.get_hand_positions(gripper_right, False)
        position_all = list(position_left + position_right)
        left_js = JointState()
        right_js = JointState()

        left_js.position.extend(position_left)
        right_js.position.extend(position_right)

        self._left_ee_cmd_publisher.publish(left_js)
        self._right_ee_cmd_publisher.publish(right_js)
    
    def move_hand(self, positions):
        left_js = JointState()
        right_js = JointState()

        left_js.position.extend(positions[:6])
        right_js.position.extend(positions[6:])

        self._left_ee_cmd_publisher.publish(left_js)
        self._right_ee_cmd_publisher.publish(right_js)
    
    # use radian
    def move_head(self, positions, uint_radian=False):
        request = BodyPoseRequest()
        request.joint_states[:] = []
        request.joint_states.extend(self._body_pose_joint_states)  # 直接替换
        request.joint_flag = 3  #设置2进制0011表示设置第1位和第2位
        request.joint_states[0] = positions[0] * (180 / np.pi) #if uint_radian else positions[0]
        request.joint_states[1] = positions[1] * (180 / np.pi) #if uint_radian else positions[1]
        # hal_logger.info(f"Move Head: {request}")
        response = self._body_pose_client.send_request(request)

    # use radian
    def move_waist(self, positions, uint_radian=False):
        request = BodyPoseRequest()
        request.joint_states[:] = []
        request.joint_states.extend(self._body_pose_joint_states)  # 直接替换
        request.joint_flag = 12  #设置2进制1100表示设置第3位和第4位
        request.joint_states[2] = positions[0] * (180 / np.pi) #if uint_radian else positions[0]
        request.joint_states[3] = positions[1] # cm
        # hal_logger.info(f"Move Waist: {request}")
        response = self._body_pose_client.send_request(request)
    
    def move_wbc_waist(self, positions):
        """
        通过 /wbc/waist_command 发送腰部控制命令

        Args:
            positions: list or array-like, 长度为2
                - positions[0]: joint_body_pitch (弧度)
                - positions[1]: joint_lift_body (m)
        """
        js = JointState()
        js.name.extend ( ['joint_body_pitch', 'joint_lift_body'])
        js.position.extend([
            float(positions[0]),  # 弧度
            float(positions[1])   # m
            ])
        self._waist_cmd_publisher.publish(js)
        hal_logger.info(f"Published to /wbc/waist_command: {js}")

    def move_wbc_head(self, positions):
        js = JointState()
        js.name.extend(['joint_head_yaw', 'joint_head_pitch'])
        js.position.extend([
            float(positions[0]),  # 弧度
            float(positions[1])   # 弧度
            ])
        self._head_cmd_publisher.publish(js)
        hal_logger.info(f"Published to /wbc/head_command: {js}")

    # use radian, cm
    def move_head_and_waist(self, head_positions, waist_positions):
        request = BodyPoseRequest()
        request.joint_states[:] = []
        request.joint_states.extend(self._body_pose_joint_states)  # 直接替换
        request.joint_flag = 15  #设置2进制1111表示设置第1位、第2位、第3位和第4位
        request.joint_states[0] = head_positions[0] * (180 / np.pi)
        request.joint_states[1] = head_positions[1] * (180 / np.pi)
        request.joint_states[2] = waist_positions[0] * (180 / np.pi)
        request.joint_states[3] = waist_positions[1] # cm
        # hal_logger.info(f"Move Head and Waist: {request}")
        response = self._body_pose_client.send_request(request)

    def move_gripper(self, positions):
        left_js = JointState()
        right_js = JointState()

        if positions[0] > 1.0:
            positions[0] = (positions[0] - 35.0) / (120.0 - 35.0)
        if positions[1] > 1.0:
            positions[1] = (positions[1] - 35.0) / (120.0 - 35.0)
        
        left_js.position.extend(positions[:1])
        right_js.position.extend(positions[1:])

        self._left_ee_cmd_publisher.publish(left_js)
        self._right_ee_cmd_publisher.publish(right_js)

    def move_arm(self, positions):
        js = JointState()
        js.name.extend(self.arm_joint_names)  # 直接替换
        js.position.extend(positions)
        self._arm_cmd_publisher.publish(js)
        # hal_logger.info(f"Move Arm: {js}")

    def check_security_reset(self, arm_positions=None, safety_margin=0.5):
        if arm_positions is None:
            arm_positions = self.arm_initial_joint_position
        for i in range(len(arm_positions)):
            if abs(self._arm_joint_states.position[i] - arm_positions[i]) > safety_margin:
                return False
        return True
    
    def fault_clear(self):
        request = TriggerRequest()
        request.structure_needs_at_least_one_member = 0
        response = self._fault_clear_client.send_request(request)
        return response
    
    def whole_body_status_callback(self, msg):
        self._whole_body_status = WholeBodyStatus()
        self._whole_body_status.header.stamp.sec = msg.header.stamp.sec
        self._whole_body_status.header.stamp.nanosec = msg.header.stamp.nanosec
        self._whole_body_status.right_arm_error = msg.right_arm_error
        self._whole_body_status.left_arm_error = msg.left_arm_error
        self._whole_body_status.right_arm_control = msg.right_arm_control
        self._whole_body_status.left_arm_control = msg.left_arm_control
        self._whole_body_status.right_arm_estop = msg.right_arm_estop
        self._whole_body_status.left_arm_estop = msg.left_arm_estop
        self._whole_body_status.right_end_error = msg.right_end_error
        self._whole_body_status.left_end_error = msg.left_end_error
        self._whole_body_status.right_end_model = msg.right_end_model
        self._whole_body_status.left_end_model = msg.left_end_model
        self._whole_body_status.waist_error = msg.waist_error
        self._whole_body_status.lift_error = msg.lift_error
        self._whole_body_status.neck_error = msg.neck_error
        self._whole_body_status.chassis_error = msg.chassis_error
    
    def whole_body_status(self):
        whole_body_status={}
        whole_body_status['right_arm_error'] = self._whole_body_status.right_arm_error
        whole_body_status['left_arm_error'] = self._whole_body_status.left_arm_error
        whole_body_status['right_arm_control'] = self._whole_body_status.right_arm_control
        whole_body_status['left_arm_control'] = self._whole_body_status.left_arm_control
        whole_body_status['right_arm_estop'] = self._whole_body_status.right_arm_estop
        whole_body_status['left_arm_estop'] = self._whole_body_status.left_arm_estop
        whole_body_status['right_end_error'] = self._whole_body_status.right_end_error
        whole_body_status['left_end_error'] = self._whole_body_status.left_end_error
        whole_body_status['right_end_model'] = self._whole_body_status.right_end_model
        whole_body_status['left_end_model'] = self._whole_body_status.left_end_model
        whole_body_status['waist_error'] = self._whole_body_status.waist_error
        whole_body_status['lift_error'] = self._whole_body_status.lift_error
        whole_body_status['neck_error'] = self._whole_body_status.neck_error
        whole_body_status['chassis_error'] = self._whole_body_status.chassis_error

        return whole_body_status, self._whole_body_status.header.stamp.sec * 1e9 + self._whole_body_status.header.stamp.nanosec
        
    def reset(self, arm_positions=None, gripper_positions=None, hand_positions=None, waist_positions=None, head_positions=None):
        if arm_positions is not None:
            timeout = 10
            while len(self._arm_joint_states.position) == 0 and timeout > 0:
                time.sleep(0.1)
                timeout -= 1

            if len(self._arm_joint_states.position) == 0:
                raise Exception("Arm joint states not ready, reset failed")

            qpos = list(self._arm_joint_states.position)

            dof = 14
            interval = 0.01
            rk = ruckig.Ruckig(dof, interval)
            rk_input = ruckig.InputParameter(dof)
            rk_output = ruckig.OutputParameter(dof)
            rk_input.current_position = qpos
            rk_input.current_velocity = [0.0] * 14
            rk_input.current_acceleration = [0.0] * 14

            rk_input.target_position = arm_positions[:14]
            rk_input.target_velocity = [0.0] * 14
            rk_input.target_acceleration = [0.0] * 14

            rk_input.max_velocity = [2.0] * 14
            rk_input.max_acceleration = [1.0] * 14
            rk_input.max_jerk = [5.0] * 14

            trajs = []
            while rk.update(rk_input, rk_output) == ruckig.Result.Working:
                trajs.append(rk_output.new_position)
                rk_output.pass_to_input(rk_input)
            for traj in trajs:      
                self.move_arm(traj)
                time.sleep(interval)
        
        if gripper_positions is not None:
            self.move_gripper([0.0, 0.0] if gripper_positions is None else gripper_positions)
        if hand_positions is not None:
            self.move_hand( self.hand_initial_joint_position if hand_positions is None else hand_positions)
        if waist_positions is not None:
            self.move_waist(self.waist_initial_joint_position if waist_positions is None else waist_positions)
        if head_positions is not None:
            self.move_head(self.head_initial_joint_position if head_positions is None else head_positions)

    def shutdown(self):
        agibotdds.shutdown()
