#!/usr/bin/env python3
from pynput import keyboard
import time
import sys
import tty
import termios
import argparse
from threading import Lock
from a2d_sdk.robot import RobotDds as Robot
from a2d_sdk.robot import Slam

class MapBuilder:
    def __init__(self):
        self._robot_controlller = Robot()
        self._slam_controller = Slam()
        
        # 初始化状态机
        self.move_state = {
            "up": False, "down": False,
            "left": False, "right": False
        }
        self.slam_active = False
        self.exit_flag = False
        self.lock = Lock()
        
        # 终端设置
        self.old_settings = termios.tcgetattr(sys.stdin)

    def __enter__(self):
        tty.setcbreak(sys.stdin.fileno())
        return self

    def __exit__(self, type, value, traceback):
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.old_settings)

    def on_press(self, key):
        try:
            with self.lock:
                # 方向键处理
                if self.slam_active:
                    if key == keyboard.Key.up:
                        print("press up")
                        self.move_state["up"] = True
                    elif key == keyboard.Key.down:
                        print("press down")
                        self.move_state["down"] = True
                    elif key == keyboard.Key.left:
                        print("press left")
                        self.move_state["left"] = True
                    elif key == keyboard.Key.right:
                        print("press right")
                        self.move_state["right"] = True

                # 功能键处理
                if hasattr(key, 'char'):
                    if key.char == 's' and not self.slam_active:
                        self.slam_active = True
                        sys.stdout.write("\nstart build map\n")
                        
                    elif key.char == 'q':
                        if self.slam_active:
                            self.slam_active = False
                            sys.stdout.write("\nstop build map\n")
                    sys.stdout.flush()
                    return False if key.char == 'q' else None
        except Exception as e:
            print(e)
            return
            
    def on_release(self, key):
        with self.lock:
            if key == keyboard.Key.up:
                print("release up")
                self.move_state["up"] = False
            elif key == keyboard.Key.down:
                print("release down")
                self.move_state["down"] = False
            elif key == keyboard.Key.left:
                print("release left")
                self.move_state["left"] = False
            elif key == keyboard.Key.right:
                print("release right")
                self.move_state["right"] = False

    def run_control_loop(self, speed, angle):
        try:
            while  not self.exit_flag:
                # 运动控制逻辑（示例）
                with self.lock:
                    if self.slam_active and any(self.move_state.values()):
                        if self.move_state["up"]:
                            self.move_state["up"] = False
                            self._robot_controlller.move_wheel(speed, 0.0)
                        elif self.move_state["down"]:
                            self.move_state["down"] = False
                            self._robot_controlller.move_wheel(-speed, 0.0)
                        elif self.move_state["left"]:
                            self.move_state["left"] = False
                            self._robot_controlller.move_wheel(0.0, angle)
                        elif self.move_state["right"]:
                            self.move_state["right"] = False
                            self._robot_controlller.move_wheel(0.0, -angle)
                            
        except KeyboardInterrupt:
            print("quit")
            self.exit_flag = True
            return

    def run(self, speed, angle):
        with keyboard.Listener(
            on_press=self.on_press,
            on_release=self.on_release) as listener:
            
            with self:
                print("press 's' to start, 'q' to exit")
                self.run_control_loop(speed, angle)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("-s", type=float, default=0.08, help="linear velocity (m/s)")
    parser.add_argument("-a", type=float, default=0.05, help="steering angular velocity (rad/s) ")
    args = parser.parse_args()
    speed = args.s
    angle = args.a
    try:
        controller = MapBuilder()
        controller.run(speed, angle)
    except Exception as e:
        print(e)
        sys.exit(1)

if __name__ == '__main__':
    main()
