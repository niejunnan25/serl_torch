#! /usr/bin/env python3
# -*- coding: utf-8 -*-

import math
import h5py
import numpy as np
import sys
import threading
import time
import argparse
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker 

current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(os.path.dirname(current_dir))

from a2d_sdk.robot import RobotDds

waist_initial_joint_position = [0.523, 28]
head_initial_joint_position = [0.000, 0.506]
arm_initial_joint_position = [
    0.881, 0.671, -0.5369, -1.8702, 0.8555, 0.6907, 1.1398,
    -0.881, -0.671, 0.5369, 1.8702, -0.8555, -0.6907, -1.1398
]
hand_initial_joint_position = [
    0.881, 0.671, -0.5369, -1.8702, 0.8555, 0.6907, 
    -0.881, -0.671, 0.5369, 1.8702, -0.8555, -0.6907,
]

class A2dDataset():
    def __init__(self, data_path: str, batch_size: int = 1, start_index: int = 0, end_index: int = -1,effector_type: str = "gripper") -> None:
        self.batch_size = batch_size
        self.start_index = start_index
        self.end_index = end_index
        self.dataset = []
        self.effector_type = effector_type
        with h5py.File(data_path, "r") as f:
            data = {}
            data['joint'] = np.array(f['action/joint/position'])[self.start_index:self.end_index]
            data['timestamp'] = np.array(f['timestamp'])[self.start_index:self.end_index]
            if self.effector_type == "oy":
                data['left_effector'] = np.array(f['action/left_effector/position'])[self.start_index:self.end_index]
                data['left_effector'][:,0]=(data['left_effector'][:,0]*180/np.pi+19.48056)* (np.pi / 180)
                data['left_effector'][:,1]=(180-19.48056-data['left_effector'][:,1]*180/np.pi)* (np.pi / 180)
                data['left_effector'][:,2]=(180-19.48056-data['left_effector'][:,2]*180/np.pi)* (np.pi / 180)
                data['left_effector'][:,3]=(180-19.48056-data['left_effector'][:,3]*180/np.pi)* (np.pi / 180)
                data['left_effector'][:,4]=(180-19.48056-data['left_effector'][:,4]*180/np.pi)* (np.pi / 180)
                data['left_effector'][:,5]=(19.48056-data['left_effector'][:,5]*180/np.pi)* (np.pi / 180)
                data['right_effector'] = np.array(f['action/right_effector/position'])[self.start_index:self.end_index]
                data['right_effector'][:,0]=(data['right_effector'][:,0]*180/np.pi+19.48056)* (np.pi / 180)
                data['right_effector'][:,1]=(180-19.48056-data['right_effector'][:,1]*180/np.pi)* (np.pi / 180)
                data['right_effector'][:,2]=(180-19.48056-data['right_effector'][:,2]*180/np.pi)* (np.pi / 180)
                data['right_effector'][:,3]=(180-19.48056-data['right_effector'][:,3]*180/np.pi)* (np.pi / 180)
                data['right_effector'][:,4]=(180-19.48056-data['right_effector'][:,4]*180/np.pi)* (np.pi / 180)
                data['right_effector'][:,5]=(19.48056-data['right_effector'][:,5]*180/np.pi)* (np.pi / 180)
            elif self.effector_type in ["SkillHandS6","gripper"] :
                data['left_effector'] = np.array(f['action/left_effector/position'])[self.start_index:self.end_index]
                data['right_effector'] = np.array(f['action/right_effector/position'])[self.start_index:self.end_index]

            waist_data = np.array(f['state/waist/position'])[self.start_index:self.end_index]
            data['waist'] = waist_data.copy() 
            #data['waist'][:, 1] *= 100  
            data['head'] = np.array(f['state/head/position'])[self.start_index:self.end_index]
            data['wheel'] = np.array(f['action/robot/velocity'])[self.start_index:self.end_index]
            data['timestamp'] = np.array(f['timestamp'])[self.start_index:self.end_index]
            if self.effector_type == "oy":
                data['left_effector_st'] = np.array(f['state/left_effector/position'])[self.start_index:self.end_index]
                data['left_effector_st'][:,0]=(data['left_effector_st'][:,0]*180/np.pi+19.48056)* (np.pi / 180)
                data['left_effector_st'][:,1]=(180-19.48056-data['left_effector_st'][:,1]*180/np.pi)* (np.pi / 180)
                data['left_effector_st'][:,2]=(180-19.48056-data['left_effector_st'][:,2]*180/np.pi)* (np.pi / 180)
                data['left_effector_st'][:,3]=(180-19.48056-data['left_effector_st'][:,3]*180/np.pi)* (np.pi / 180)
                data['left_effector_st'][:,4]=(180-19.48056-data['left_effector_st'][:,4]*180/np.pi)* (np.pi / 180)
                data['left_effector_st'][:,5]=(19.48056-data['left_effector_st'][:,5]*180/np.pi)* (np.pi / 180)
                data['right_effector_st'] = np.array(f['state/right_effector/position'])[self.start_index:self.end_index]
                data['right_effector_st'][:,0]=(data['right_effector_st'][:,0]*180/np.pi+19.48056)* (np.pi / 180)
                data['right_effector_st'][:,1]=(180-19.48056-data['right_effector_st'][:,1]*180/np.pi)* (np.pi / 180)
                data['right_effector_st'][:,2]=(180-19.48056-data['right_effector_st'][:,2]*180/np.pi)* (np.pi / 180)
                data['right_effector_st'][:,3]=(180-19.48056-data['right_effector_st'][:,3]*180/np.pi)* (np.pi / 180)
                data['right_effector_st'][:,4]=(180-19.48056-data['right_effector_st'][:,4]*180/np.pi)* (np.pi / 180)
                data['right_effector_st'][:,5]=(19.48056-data['right_effector_st'][:,5]*180/np.pi)* (np.pi / 180)
            elif self.effector_type in ["SkillHandS6","gripper"] :
                data['left_effector_st'] = np.array(f['state/left_effector/position'])[self.start_index:self.end_index]
                data['right_effector_st'] = np.array(f['state/right_effector/position'])[self.start_index:self.end_index]
            data['left_effector_st'] = np.where(data['left_effector_st'] < 1.0,
                                                data['left_effector_st'] * 85 + 35,
                                                data['left_effector_st'])
            data['right_effector_st'] = np.where(data['right_effector_st'] < 1.0,
                                                data['right_effector_st'] * 85 + 35,
                                                data['right_effector_st'])
            data['joint_st'] = np.array(f['state/joint/position'])[self.start_index:self.end_index]
            waist_data_st = np.array(f['state/waist/position'])[self.start_index:self.end_index]
            data['waist_st'] = waist_data_st.copy() 
            data['waist_st'][:, 1] *= 100 
            data['head_st'] = np.array(f['state/head/position'])[self.start_index:self.end_index]
            self.dataset.append(data)
        self.data_length = len(self.dataset[0]['joint'])
        for key, value in self.dataset[0].items():
            print(f"{key}: {value.shape}")

    def __len__(self):
        return self.data_length

    def __getitem__(self, index: int):
        data = {key: value[index] for key, value in self.dataset[0].items()}
        return data

    def next(self):
        for i in range(0, self.data_length, self.batch_size):
            batch_data = {key: value[i:i + self.batch_size] for key, value in self.dataset[0].items()}
            yield batch_data

class RealtimeData():
    def __init__(self, robot: RobotDds, output_dir: str,effector_type: str = "gripper"):
        self.robot = robot
        self.output_dir = output_dir
        self.effector_type = effector_type
        os.makedirs(self.output_dir, exist_ok=True)
        self.h5_file = h5py.File(os.path.join(self.output_dir, "realtime_data.h5"), 'w') 
        self.h5_file.create_dataset("state/joint/position", (0, 14), maxshape=(None, 14), dtype=np.float32)
        self.h5_file.create_dataset("state/waist/position", (0, 2), maxshape=(None, 2), dtype=np.float32)
        self.h5_file.create_dataset("state/head/position", (0, 2), maxshape=(None, 2), dtype=np.float32)
        if self.effector_type in ["oy", "SkillHandS6"]:
            self.h5_file.create_dataset("state/left_effector/position", (0, 6), maxshape=(None, 6), dtype=np.float32)
            self.h5_file.create_dataset("state/right_effector/position", (0, 6), maxshape=(None, 6), dtype=np.float32)
            self.h5_file.create_dataset("action/left_effector/command", (0, 6), maxshape=(None, 6), dtype=np.float32)
            self.h5_file.create_dataset("action/right_effector/command", (0, 6), maxshape=(None, 6), dtype=np.float32)
            self.h5_file.create_dataset("error/left_effector", (0, 6), maxshape=(None, 6), dtype=np.float32)
            self.h5_file.create_dataset("error/right_effector", (0, 6), maxshape=(None, 6), dtype=np.float32)
        elif self.effector_type == "gripper":
            self.h5_file.create_dataset("state/left_effector/position", (0, 1), maxshape=(None, 2), dtype=np.float32)
            self.h5_file.create_dataset("state/right_effector/position", (0, 1), maxshape=(None, 2), dtype=np.float32)
            self.h5_file.create_dataset("action/left_effector/command", (0, 1), maxshape=(None, 2), dtype=np.float32)
            self.h5_file.create_dataset("action/right_effector/command", (0, 1), maxshape=(None, 2), dtype=np.float32)
            self.h5_file.create_dataset("error/left_effector", (0, 1), maxshape=(None, 2), dtype=np.float32)
            self.h5_file.create_dataset("error/right_effector", (0, 1), maxshape=(None, 2), dtype=np.float32)

        self.h5_file.create_dataset("action/joint/command", (0, 14), maxshape=(None, 14), dtype=np.float32)
        self.h5_file.create_dataset("action/waist/command", (0, 2), maxshape=(None, 2), dtype=np.float32)
        self.h5_file.create_dataset("action/head/command", (0, 2), maxshape=(None, 2), dtype=np.float32)
        self.h5_file.create_dataset("timestamp", (0,), maxshape=(None,), dtype=np.float64)
        self.h5_file.create_dataset("error/joint", (0, 14), maxshape=(None, 14), dtype=np.float32)
        self.h5_file.create_dataset("error/velocity", (0, 2), maxshape=(None, 2), dtype=np.float32)
        self.h5_file.create_dataset("error/head", (0, 2), maxshape=(None, 2), dtype=np.float32)
        self.h5_file.create_dataset("error/waist", (0, 2), maxshape=(None, 2), dtype=np.float32)
    
    def save_data(self, timestamp, joint_position, left_effector_position, right_effector_position, head_position, waist_position,joint_command,left_effector_command,right_effector_command,head_command,waist_command):
        self._append_to_dataset("timestamp", [timestamp])
        self._append_to_dataset("state/joint/position", joint_position)
        self._append_to_dataset("state/left_effector/position", left_effector_position)
        self._append_to_dataset("state/right_effector/position", right_effector_position)
        self._append_to_dataset("state/head/position", head_position)
        self._append_to_dataset("state/waist/position", waist_position)
        self._append_to_dataset("action/joint/command", joint_command)
        self._append_to_dataset("action/left_effector/command", left_effector_command)
        self._append_to_dataset("action/right_effector/command", right_effector_command)
        self._append_to_dataset("action/head/command", head_command)
        self._append_to_dataset("action/waist/command", waist_command)
        self.h5_file.flush()

    def save_error(self, collected, realtime,effector_type: str = "gripper"):
        left_eff_collected = collected.get("left_effector", None)
        right_eff_collected = collected.get("right_effector", None)
        if self.effector_type in ["oy", "SkillHandS6"]:
            left_eff_error = np.array(left_eff_collected if left_eff_collected is not None else np.zeros(6)) \
                    - np.array(realtime["left_effector"])
            right_eff_error = np.array(right_eff_collected if right_eff_collected is not None else np.zeros(6)) \
                    - np.array(realtime["right_effector"])
        elif self.effector_type == "gripper":
            left_eff_error = np.array(left_eff_collected if left_eff_collected is not None else np.zeros(1)) \
                        - np.array(realtime["left_effector"])
            right_eff_error = np.array(right_eff_collected if right_eff_collected is not None else np.zeros(1)) \
                        - np.array(realtime["right_effector"])
        error = {
            "waist": np.array(collected.get("waist", np.zeros(2))) - np.array(realtime["waist"]),
            "head": np.array(collected.get("head", np.zeros(2))) - np.array(realtime["head"]),
            "left_effector": left_eff_error,
            "right_effector": right_eff_error,
            "joint": np.array(collected.get("joint", np.zeros(14))) - np.array(realtime["joint"]),
        }
        self._append_to_dataset("error/waist", error["waist"])
        self._append_to_dataset("error/head", error["head"])
        self._append_to_dataset("error/left_effector", error["left_effector"])
        self._append_to_dataset("error/right_effector", error["right_effector"])
        self._append_to_dataset("error/joint", error["joint"])
        self.h5_file.flush()
    
    def _append_to_dataset(self, dataset_name:str, data):
        dataset = self.h5_file[dataset_name]
        dataset.resize(dataset.shape[0] + 1, axis=0)
        dataset[-1] = data
                
    def close(self):
        if hasattr(self, 'h5_file') and self.h5_file is not None:
            self.h5_file.close()
            self.h5_file = None

def visualize_errors(h5_file_path, output_dir=".",effector_type: str = "gripper"):
    os.makedirs(output_dir, exist_ok=True)
    with h5py.File(h5_file_path, 'r') as f:
        timestamps = f['timestamp'][:]
        joint_errors = f['error/joint'][:]
        left_effector_errors = f['error/left_effector'][:]
        right_effector_errors = f['error/right_effector'][:]
        head_errors = f['error/head'][:]
        waist_errors = f['error/waist'][:]

    timestamps_seconds = timestamps / 1e9
    start_time = timestamps_seconds[0]
    timestamps_seconds -= start_time
    timestamps_seconds = timestamps_seconds[1:]
    joint_errors = joint_errors[1:, :]
    left_effector_errors = left_effector_errors[1:, :]
    right_effector_errors = right_effector_errors[1:, :]
    head_errors = head_errors[1:, :]
    waist_errors = waist_errors[1:, :]
    fig, axs = plt.subplots(6, 1, figsize=(10, 15))  
    fig.tight_layout(pad=3.0)  
    for i in range(7):  # 关节0-6
        joint_data = joint_errors[:, i]
        data_min = joint_data.min()
        data_max = joint_data.max()
        lower_bound = np.floor(data_min / 0.1) * 0.1  
        upper_bound = np.ceil(data_max / 0.1) * 0.1  
        axs[0].plot(timestamps_seconds, joint_data, label=f'Joint {i} Error', linestyle='-')
    axs[0].set_title('Joint_left Errors')
    axs[0].set_xlabel('Time (seconds)')
    axs[0].set_ylabel('Error')
    axs[0].legend()
    axs[0].xaxis.set_major_locator(ticker.MultipleLocator(1))
    axs[0].xaxis.set_minor_locator(ticker.MultipleLocator(0.2))
    axs[0].yaxis.set_major_locator(ticker.MultipleLocator(0.1))
    axs[0].set_ylim([lower_bound, upper_bound])
    for i in range(7, 14):  # 关节7-13
        joint_data = joint_errors[:, i]
        data_min = joint_data.min()
        data_max = joint_data.max()
        lower_bound = np.floor(data_min / 0.1) * 0.1 
        upper_bound = np.ceil(data_max / 0.1) * 0.1  
        axs[1].plot(timestamps_seconds, joint_data, label=f'Joint {i} Error', linestyle='-')
    axs[1].set_title('Joint_right Errors')
    axs[1].set_xlabel('Time (seconds)')
    axs[1].set_ylabel('Error')
    axs[1].legend()
    axs[1].xaxis.set_major_locator(ticker.MultipleLocator(1))
    axs[1].xaxis.set_minor_locator(ticker.MultipleLocator(0.2))
    axs[1].yaxis.set_major_locator(ticker.MultipleLocator(0.1))
    axs[1].set_ylim([lower_bound, upper_bound])

    if effector_type in ["oy", "SkillHandS6"]:
        labels = [f"hand_{i}" for i in range(1, 7)]
        for col, label in enumerate(labels):
            axs[2].plot(timestamps_seconds, left_effector_errors[:, col], label='right'+label)
            axs[3].plot(timestamps_seconds, right_effector_errors[:, col], label='left'+label)
    elif effector_type == "gripper":
        labels = ["Gripper Left", "Gripper Right"]
        axs[2].plot(timestamps_seconds, left_effector_errors[:, 0], label="left gripper")
        axs[3].plot(timestamps_seconds, right_effector_errors[:, 0], label="right gripper")
            

    axs[2].set_title('Left Effector Errors')
    axs[2].set_xlabel('Time (seconds)')
    axs[2].set_ylabel('Error')
    axs[2].legend()
    axs[2].xaxis.set_major_locator(ticker.MultipleLocator(1))
    axs[2].xaxis.set_minor_locator(ticker.MultipleLocator(0.2))
    axs[2].grid(which='both', linestyle='--', linewidth=0.5)

    axs[3].set_title('Right Effector Errors')
    axs[3].set_xlabel('Time (seconds)')
    axs[3].set_ylabel('Error')
    axs[3].legend()
    axs[3].xaxis.set_major_locator(ticker.MultipleLocator(1))
    axs[3].xaxis.set_minor_locator(ticker.MultipleLocator(0.2))
    axs[3].grid(which='both', linestyle='--', linewidth=0.5)

    he_data_min = head_errors.min()
    he_data_max = head_errors.max() 
    he_lower_bound = np.floor(he_data_min / 0.1) * 0.1 
    he_upper_bound = np.ceil(he_data_max / 0.1) * 0.1  
    axs[4].plot(timestamps_seconds, head_errors[:, 0], label='Head Pitch')
    axs[4].plot(timestamps_seconds, head_errors[:, 1], label='Head Yaw')
    axs[4].set_title('Head Errors')
    axs[4].set_xlabel('Time (seconds)')
    axs[4].set_ylabel('Error')
    axs[4].legend()
    axs[4].xaxis.set_major_locator(ticker.MultipleLocator(1))
    axs[4].xaxis.set_minor_locator(ticker.MultipleLocator(0.2))
    axs[4].yaxis.set_major_locator(ticker.MultipleLocator(0.1))
    axs[4].set_ylim([he_lower_bound, he_upper_bound])
    axs[4].grid(which='both', linestyle='--', linewidth=0.5)

    wa_data_min = waist_errors.min()
    wa_data_max = waist_errors.max()
    wa_lower_bound = np.floor(wa_data_min / 0.1) * 0.1  
    wa_upper_bound = np.ceil(wa_data_max / 0.1) * 0.1  
    axs[5].plot(timestamps_seconds, waist_errors[:, 0], label='Waist Motor 1')
    axs[5].plot(timestamps_seconds, waist_errors[:, 1], label='Waist Motor 2')
    axs[5].set_title('Waist Errors')
    axs[5].set_xlabel('Time (seconds)')
    axs[5].set_ylabel('Error')
    axs[5].legend()
    axs[5].xaxis.set_major_locator(ticker.MultipleLocator(1))
    axs[5].xaxis.set_minor_locator(ticker.MultipleLocator(0.2))
    axs[5].yaxis.set_major_locator(ticker.MultipleLocator(0.1))
    axs[5].set_ylim([wa_lower_bound, wa_upper_bound])
    axs[5].grid(which='both', linestyle='--', linewidth=0.5)

    error_plot_path = os.path.join(output_dir, 'error_plots1.png')
    plt.savefig(error_plot_path)
    print(f"Error plots saved at {error_plot_path}")
    plt.close()

def visualize_data_with_real(h5_file_path, real_file_path, output_dir=".",effector_type: str = "gripper"):
    os.makedirs(output_dir, exist_ok=True)
    with h5py.File(h5_file_path, 'r') as f:
        timestamps = f['timestamp'][:]
        action_joint_position = f['action/joint/position'][1:]
        state_joint_position = f['state/joint/position'][1:]
        left_effector_positions_action = f['action/left_effector/position'][1:]
        right_effector_positions_action = f['action/right_effector/position'][1:]
        left_effector_positions_state = f['state/left_effector/position'][1:]
        right_effector_positions_state = f['state/right_effector/position'][1:]
        head_positions_action = f['state/head/position'][1:]
        head_positions_state = f['state/head/position'][1:]
        waist_positions_action = f['state/waist/position'][1:]
        waist_positions_action[:, 1] *= 100
        waist_positions_state = f['state/waist/position'][1:]
        waist_positions_state[:, 1] *= 100
    with h5py.File(real_file_path, 'r') as f:
        joint_positions_real = f['state/joint/position'][1:]
        left_effector_positions_real = f['state/left_effector/position'][1:]
        right_effector_positions_real = f['state/right_effector/position'][1:]
        head_positions_real = f['state/head/position'][1:]
        waist_positions_real = f['state/waist/position'][1:]
        joint_positions_action_real = f['action/joint/command'][1:]
        left_effector_positions_action_real = f['action/left_effector/command'][1:]
        right_effector_positions_action_real = f['action/right_effector/command'][1:]
        head_positions_action_real = f['action/head/command'][1:]
        waist_positions_action_real = f['action/waist/command'][1:]
    real_length = min(len(joint_positions_real), len(timestamps))
    timestamps_seconds = timestamps / 1e9
    start_time = timestamps_seconds[0]
    timestamps_seconds -= start_time
    timestamps_seconds = timestamps_seconds[:len(joint_positions_real)]
    joint_positions_real = joint_positions_real[:len(timestamps_seconds)]

    fig1, axes1 = plt.subplots(7, 2, figsize=(14, 14))
    axes1 = axes1.flatten()
    for i in range(min(action_joint_position.shape[1], len(axes1))):  
        ax = axes1[i]
        joint_data = action_joint_position[:real_length, i]
        state_data = state_joint_position[:real_length, i]
        replay_data = joint_positions_real[:real_length, i]
        action_real_data = joint_positions_action_real[:real_length, i]  
        data_min = min(joint_data.min(), state_data.min(), replay_data.min(), action_real_data.min())
        data_max = max(joint_data.max(), state_data.max(), replay_data.max(), action_real_data.max())
        data_range = data_max - data_min
        if data_range < 0.01:
            lower_bound = np.floor(data_min / 0.1) * 0.1  
            upper_bound = np.ceil(data_max / 0.1) * 0.1  
        else:
            lower_bound = data_min  
            upper_bound = data_max  
        ax.plot(timestamps_seconds, joint_data, label=f'Joint {i} Action', linestyle='-')
        ax.plot(timestamps_seconds, state_data, label=f'Joint {i} State', linestyle='--')
        ax.plot(timestamps_seconds, replay_data, label=f'Joint {i} Replay_state', linestyle='-.')
        ax.plot(timestamps_seconds, action_real_data, label=f'Joint {i} Action (Real)', linestyle=':')
        ax.set_title(f'Joint {i} Position: Action vs State vs Replay_action vs Replay_state')
        ax.set_xlabel('Time (seconds)')
        ax.set_ylabel('Position')
        ax.legend()
        ax.xaxis.set_major_locator(ticker.MultipleLocator(1))  
        ax.xaxis.set_minor_locator(ticker.MultipleLocator(0.2))  
        ax.yaxis.set_major_locator(ticker.MultipleLocator(0.1))  
        ax.set_ylim(lower_bound, upper_bound) 

    fig2, axes2 = plt.subplots(4,1, figsize=(12, 12))
    axes2 = axes2.flatten()

    ax = axes2[0]
    mask_action_real = left_effector_positions_action_real[:real_length, :] != 0
    if effector_type in ["oy", "SkillHandS6"]:
        for col in range(6):
            if np.any(mask_action_real[:, col]):
                ax.plot(
                    timestamps_seconds[mask_action_real[:, col]],
                    left_effector_positions_action[:real_length, col][mask_action_real[:, col]],
                    label=f'Hand {col+1} Action',
                    linestyle='--'
                )
                ax.plot(
                    timestamps_seconds[mask_action_real[:, col]],
                    left_effector_positions_state[:real_length, col][mask_action_real[:, col]],
                    label=f'Hand {col+1} State',
                    linestyle='-'
                )
                ax.plot(
                    timestamps_seconds[mask_action_real[:, col]],
                    left_effector_positions_real[:real_length, col][mask_action_real[:, col]],
                    label=f'Hand {col+1} Replay_state',
                    linestyle='-.'
                )
                ax.plot(
                    timestamps_seconds[mask_action_real[:, col]],
                    left_effector_positions_action_real[:real_length, col][mask_action_real[:, col]],
                    label=f'Hand {col+1} Action (Real)',
                    linestyle=':'
                )
    elif effector_type == "gripper":
        sides = ["Left", "Right"]
        ax.plot(
            timestamps_seconds[mask_action_real[:, 0]],
            left_effector_positions_action[:real_length, 0][mask_action_real[:, 0]],
            label=f'LeftGripper Action',
            linestyle='--'
        )
        ax.plot(
            timestamps_seconds[mask_action_real[:, 0]],
            left_effector_positions_state[:real_length, 0][mask_action_real[:, 0]],
            label=f'LeftGripper State',
            linestyle='-'
        )
        ax.plot(
            timestamps_seconds[mask_action_real[:, 0]],
            left_effector_positions_real[:real_length, 0][mask_action_real[:, 0]],
            label=f'LeftGripper Replay_state',
            linestyle='-.'
        )
        ax.plot(
            timestamps_seconds[mask_action_real[:, 0]],
            left_effector_positions_action_real[:real_length, 0][mask_action_real[:, 0]],
            label=f'LeftGripper Action (Real)',
            linestyle=':'
            )
    ax.set_title('Left Effector Positions: Action vs State vs Replay_action vs Replay_state')
    ax.set_xlabel('Time (seconds)')
    ax.set_ylabel('Position')
    ax.legend()
    ax.xaxis.set_major_locator(ticker.MultipleLocator(1))
    ax.xaxis.set_minor_locator(ticker.MultipleLocator(0.2))
    
    ax = axes2[1]
    mask_action_real = right_effector_positions_action_real[:real_length, :] != 0
    if effector_type in ["oy", "SkillHandS6"]:
        for col in range(6):
            if np.any(mask_action_real[:, col]):
                ax.plot(
                    timestamps_seconds[mask_action_real[:, col]],
                    right_effector_positions_action[:real_length, col][mask_action_real[:, col]],
                    label=f'Hand {col+1} Action',
                    linestyle='--'
                )
                ax.plot(
                    timestamps_seconds[mask_action_real[:, col]],
                    right_effector_positions_state[:real_length, col][mask_action_real[:, col]],
                    label=f'Hand {col+1} State',
                    linestyle='-'
                )
                ax.plot(
                    timestamps_seconds[mask_action_real[:, col]],
                    right_effector_positions_real[:real_length, col][mask_action_real[:, col]],
                    label=f'Hand {col+1} Replay_state',
                    linestyle='-.'
                )
                ax.plot(
                    timestamps_seconds[mask_action_real[:, col]],
                    right_effector_positions_action_real[:real_length, col][mask_action_real[:, col]],
                    label=f'Hand {col+1} Action (Real)',
                    linestyle=':'
                )
    elif effector_type == "gripper":
        sides = ["Left", "Right"]
        ax.plot(
            timestamps_seconds[mask_action_real[:, 0]],
            right_effector_positions_action[:real_length, 0][mask_action_real[:, 0]],
            label=f'RightGripper Action',
            linestyle='--'
        )
        ax.plot(
            timestamps_seconds[mask_action_real[:, 0]],
            right_effector_positions_state[:real_length, 0][mask_action_real[:, 0]],
            label=f'RightGripper State',
            linestyle='-'
        )
        ax.plot(
            timestamps_seconds[mask_action_real[:, 0]],
            right_effector_positions_real[:real_length, 0][mask_action_real[:, 0]],
            label=f'RightGripper Replay_state',
            linestyle='-.'
        )
        ax.plot(
            timestamps_seconds[mask_action_real[:, 0]],
            right_effector_positions_action_real[:real_length, 0][mask_action_real[:, 0]],
            label=f'RightGripper Action (Real)',
            linestyle=':'
        )
        
    ax.set_title('Right Effector Positions: Action vs State vs Replay_action vs Replay_state')
    ax.set_xlabel('Time (seconds)')
    ax.set_ylabel('Position')
    ax.legend()
    ax.xaxis.set_major_locator(ticker.MultipleLocator(1))
    ax.xaxis.set_minor_locator(ticker.MultipleLocator(0.2))
    
    ax = axes2[2]
    ax.plot(timestamps_seconds, head_positions_action[:real_length, 0], label='Head Pitch Action', linestyle='--')
    ax.plot(timestamps_seconds, head_positions_state[:real_length, 0], label='Head Pitch State', linestyle='-')
    ax.plot(timestamps_seconds, head_positions_real[:real_length, 0], label='Head Pitch Replay_state', linestyle='-.')
    ax.plot(timestamps_seconds, head_positions_action_real[:real_length, 0], label='Head Pitch Action (Real)', linestyle=':')
    ax.plot(timestamps_seconds, head_positions_action[:real_length, 1], label='Head Yaw Action', linestyle='--')
    ax.plot(timestamps_seconds, head_positions_state[:real_length, 1], label='Head Yaw State', linestyle='-')
    ax.plot(timestamps_seconds, head_positions_real[:real_length, 1], label='Head Yaw Replay_state', linestyle='-.')
    ax.plot(timestamps_seconds, head_positions_action_real[:real_length, 1], label='Head Yaw Action (Real)', linestyle=':')
    ax.set_title('Head Positions: Action vs State vs Replay_action vs Replay_state')
    ax.set_xlabel('Time (seconds)')
    ax.set_ylabel('Position')
    ax.legend()
    ax.xaxis.set_major_locator(ticker.MultipleLocator(1))
    ax.xaxis.set_minor_locator(ticker.MultipleLocator(0.2))

    ax = axes2[3]
    ax.plot(timestamps_seconds, waist_positions_action[:real_length, 0], label='Waist Action (Motor 1)', linestyle='--')
    ax.plot(timestamps_seconds, waist_positions_state[:real_length, 0], label='Waist State (Motor 1)', linestyle='-')
    ax.plot(timestamps_seconds, waist_positions_real[:real_length, 0], label='Waist Replay_state (Motor 1)', linestyle='-.')
    ax.plot(timestamps_seconds, waist_positions_action_real[:real_length, 0], label='Waist Action (Real, Motor 1)', linestyle=':')
    ax.plot(timestamps_seconds, waist_positions_action[:real_length, 1], label='Waist Action (Motor 2)', linestyle='--')
    ax.plot(timestamps_seconds, waist_positions_state[:real_length, 1], label='Waist State (Motor 2)', linestyle='-')
    ax.plot(timestamps_seconds, waist_positions_real[:real_length, 1], label='Waist Replay_state (Motor 2)', linestyle='-.')
    ax.plot(timestamps_seconds, waist_positions_action_real[:real_length, 1], label='Waist Action (Real, Motor 2)', linestyle=':')
    ax.set_title('Waist Positions: Action vs State vs Replay_action vs Replay_state')
    ax.set_xlabel('Time (seconds)')
    ax.set_ylabel('Position (cm)')
    ax.legend()
    ax.xaxis.set_major_locator(ticker.MultipleLocator(1))
    ax.xaxis.set_minor_locator(ticker.MultipleLocator(0.2))

    plt.tight_layout()  
    output_path1 = os.path.join(output_dir, "joint_error_plots.png")
    plt.figure(fig1.number) 
    plt.savefig(output_path1)
    plt.close(fig1)  
    output_path2 = os.path.join(output_dir, "other_error_plots.png")
    plt.figure(fig2.number) 
    plt.savefig(output_path2)
    plt.close(fig2)  

    print(f"Error plots saved at {output_path1} and {output_path2}")

def replay(robot: RobotDds, stop_event: threading.Event, args):
    effector_type=args.t
    time.sleep(1)
    base_name = os.path.splitext(os.path.basename(args.h5))[0]
    output_dir = os.path.join(os.path.dirname(args.h5), base_name + "_error") 
    os.makedirs(output_dir, exist_ok=True)
    realtime_data = RealtimeData(robot=robot, output_dir=output_dir, effector_type=effector_type) 
    dataset = A2dDataset(data_path=args.h5, start_index=args.start, end_index=args.end, effector_type=effector_type)
    last_timestamp = 0
    last_waist_command =[-1.0, -1.0]
    for data in dataset.next():
        timestamp = data['timestamp'][0]
        joint_positions = data['joint']
        collected = {
            "joint": data.get('joint_st', [None])[0],
            "left_effector": data.get('left_effector_st', [None])[0],
            "right_effector": data.get('right_effector_st', [None])[0],
            "head": data.get('head_st', [None])[0],
            "waist": data.get('waist_st', [None])[0],
        }
        if args.t in ["oy", "SkillHandS6"]:
            current_effector = robot.hand_joint_states()[0] \
                if robot.hand_joint_states()[0] and len(robot.hand_joint_states()[0]) == 12 \
                else np.zeros(12)
            current_left_effector = current_effector[:6]
            current_right_effector = current_effector[6:]
        elif args.t == "gripper":
            current_effector = robot.gripper_states()[0] \
                if robot.gripper_states()[0] and len(robot.gripper_states()[0]) == 2 \
                else np.zeros(2)
            current_left_effector = current_effector[:1]
            current_right_effector = current_effector[1:]
        realtime = {
            "joint": robot.arm_joint_states()[0] if robot.arm_joint_states()[0] else np.zeros(14),
            "left_effector": current_left_effector,
            "right_effector": current_right_effector,
            "head": (np.array(robot.head_joint_states()[0]) * (np.pi / 180)) if (robot.head_joint_states()[0] and len(robot.head_joint_states()[0]) == 2) else np.zeros(2),
            "waist": [
                robot.waist_joint_states()[0][0] if (robot.waist_joint_states()[0][0])  else 0.0,
                robot.waist_joint_states()[0][1]*100 if (robot.waist_joint_states()[0][1]) else 0.0,
            ],
        }
        #print (f"left_effector:{realtime['left_effector']}")
        #print (f"right_effector:{realtime['right_effector']}")
        if last_timestamp == 0:
            last_timestamp = data['timestamp'][0]
            time.sleep(2)
            gripper_positions = data['left_effector'][0].tolist() + data['right_effector'][0].tolist()
            waist_position = data['waist'][0].tolist()
            last_waist_command = waist_position
            waist_position[0] = waist_position[0]
            waist_position[1] = waist_position[1]*100
            print("waist_position: ", waist_position)
            robot.reset(arm_positions=data['joint'][0].tolist(), gripper_positions=gripper_positions, head_positions=data['head'][0].tolist(),waist_positions=waist_position)
            time.sleep(10)
            print("robot.reset is finish")     
        else:
            if data['timestamp'][0] - last_timestamp > 0:
                time_diff = (timestamp - last_timestamp) / 1000000000.0 
                action_start_time = time.time()
                robot.move_arm(joint_positions[0].tolist())
               # if len(data['waist']) > 0 and len(data['head']) > 0:
                       # time.sleep(0.005) 
                       # robot.move_head_and_waist(data['head'][0].tolist(),data['waist'][0].tolist())
                if len(data['waist']) > 0:
                    if (abs(last_waist_command[0] - data['waist'][0][0])>0.00001):
                        robot.move_wbc_waist(data['waist'][0].tolist())
                        time.sleep(0.01)
                        print(f"waist command:{data['waist'][0]}")
                    last_waist_command = data['waist'][0].tolist()
                if  len(data['head']) > 0:
                    time.sleep(0.005)
                    robot.move_wbc_head(data['head'][0].tolist())
                # if len(data['head']) > 0:
                #     time.sleep(0.005)
                #     robot.move_head(data['head'][0].tolist())
                # if len(data['waist']) > 0 and len(data['head']) > 0:
                #         time.sleep(0.005) 
                #         robot.move_head_and_waist(data['head'][0].tolist(),data['waist'][0].tolist())


                left_effector_command = data['left_effector'][0].tolist()
                right_effector_command = data['right_effector'][0].tolist()
                effector_command = left_effector_command + right_effector_command
                
                #print(f"effector command: {effector_command}")
                if effector_type in ["oy", "SkillHandS6"]:
                    robot.move_hand(effector_command)
                elif effector_type == "gripper":
                    robot.move_gripper(effector_command)
                if data['wheel'][0].shape != (2,):
                    robot.move_wheel(data['wheel'][0], 0.0)
                else:
                    robot.move_wheel(data['wheel'][0][1], data['wheel'][0][1])
                action_end_time = time.time()
                action_time = action_end_time - action_start_time
                sleep_time = max(0, time_diff - action_time)
                time.sleep(sleep_time)
                last_timestamp = data['timestamp'][0]
                joint_command = joint_positions[0]  
                for i in range(len(left_effector_command)):
                    left_effector_command[i] = left_effector_command[i] * 85 + 35 if left_effector_command[i] <= 1.0 else left_effector_command[i]
                for i in range(len(right_effector_command)):
                    right_effector_command[i] = right_effector_command[i] * 85 + 35 if right_effector_command[i] <= 1.0 else right_effector_command[i]
                head_command = data['head'][0]  
                waist_command = data['waist'][0]  
                realtime_data.save_data(
                    timestamp=timestamp,
                    joint_position=realtime["joint"],
                    left_effector_position=realtime["left_effector"],
                    right_effector_position=realtime["right_effector"],
                    head_position=realtime["head"],
                    waist_position=realtime["waist"],
                    joint_command=joint_command,
                    left_effector_command=left_effector_command,
                    right_effector_command=right_effector_command,
                    head_command=head_command,
                    waist_command=waist_command
                )
                realtime_data.save_error(collected, realtime)
    robot.reset(waist_positions=waist_initial_joint_position, head_positions=head_initial_joint_position)         
    time.sleep(10)
    realtime_data.close()
    print("Generating error plots...")
    #isualize_errors(h5_file_path=os.path.join(output_dir, "realtime_data.h5"), output_dir=output_dir, effector_type=args.t)
    print("Generating error plots1 is finish.")
    #visualize_data_with_real(h5_file_path=args.h5,real_file_path=os.path.join(output_dir, "realtime_data.h5"),output_dir=output_dir, effector_type=args.t)
    print("Generating error plots2 is finish.")
    robot.shutdown()
    stop_event.set()
    

def main(args=None):
    if args is None:
        parser = argparse.ArgumentParser()
        parser.add_argument("--h5", type=str, required=True)
        parser.add_argument("--start", type=int, default=0, help="start frame index")
        parser.add_argument("--end", type=int, default=-1, help="end frame index")
        parser.add_argument("--t", type=str, default="gripper", help="type of effector")
        args = parser.parse_args()
    robot = RobotDds()
    stop_event = threading.Event()
    control_thread = threading.Thread(
       target=replay, args=(robot, stop_event, args), daemon=True
    )
    control_thread.start()

    try:
        control_thread.join()
    except KeyboardInterrupt:
        print("收到键盘中断，正在关闭节点")
    finally:
        stop_event.set()
        control_thread.join()
        print("程序退出")
        sys.exit(0)

if __name__ == '__main__':
    main()
