import signal

class ProgramBreaker:
    break_now = False
    def __init__(self):
        signal.signal(signal.SIGINT, self.break_program)
        signal.signal(signal.SIGTERM, self.break_program)

    def break_program(self, signum, _stack_frame):
      self.break_now = True

breaker = ProgramBreaker()

