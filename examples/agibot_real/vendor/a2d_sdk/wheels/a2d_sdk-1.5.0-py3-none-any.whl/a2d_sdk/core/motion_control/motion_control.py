import numpy as np
from scipy.spatial.transform import Rotation as R
from scipy.spatial.transform import Rotation
import time
from cosine_bus.agibotdds_py3 import agibotdds
import threading
from collections import deque

from geometry_msgs_pb.msg.Pose_pb2 import Pose
from geometry_msgs_pb.msg.TwistStamped_pb2 import TwistStamped
from sensor_msgs_pb.msg.JointState_pb2 import JointState
from genie_msgs_pb.msg.RetargetInfo_pb2 import RetargetInfo
from genie_msgs_pb.msg.RetargetInfoArray_pb2 import RetargetInfoArray
from genie_msgs_pb.msg.TrajectoryTrackingControl_pb2 import TrajectoryTrackingControl
from genie_msgs_pb.msg.ReactiveControl_pb2 import ReactiveControl
from genie_msgs_pb.srv.BodyPose_pb2 import BodyPose_Request as BodyPoseRequest
from genie_msgs_pb.msg.MotionControlStatus_pb2 import MotionControlStatus
from genie_msgs_pb.msg.MotionStop_pb2 import MotionStop
from genie_msgs_pb.msg.SetControlMode_pb2 import SetControlMode
from genie_msgs_pb.msg.EndEffectorPoseControl_pb2 import EndEffectorPoseControl
from genie_msgs_pb.msg.JointPositionControl_pb2 import JointPositionControl

from geometry_msgs_pb.msg.Twist_pb2 import Twist

from a2d_sdk.core.motion_control.motion_control_config import (
    DEFAULT_JOINT_POSITIONS, JOINT_NAMES, MOTION_LIMITS, 
    ARM_REFERENCE_FRAMES, GROUP_IDS, CONTROL_TYPES, GRIPPER_TO_HAND_CONFIG,
    JOINT_GROUP_IDS, POSE_GROUP_IDS
)

class MotionController:
    def __init__(self, robot_config=None):
        """Initialize motion controller with robot configuration
        
        Args:
            robot_config: Dictionary containing robot joint names and initial positions
        """
        if robot_config is None:
            self.config = {
                'waist_joint_names': JOINT_NAMES['waist'],
                'head_joint_names': JOINT_NAMES['head'],
                'arm_joint_names': JOINT_NAMES['arm'],
                'hand_joint_names': JOINT_NAMES['hand'],
                'gripper_joint_names': JOINT_NAMES['gripper'],
                'waist_initial_joint_position': DEFAULT_JOINT_POSITIONS['waist'],
                'head_initial_joint_position': DEFAULT_JOINT_POSITIONS['head'],
                'arm_initial_joint_position': DEFAULT_JOINT_POSITIONS['arm'],
                'hand_initial_joint_position': DEFAULT_JOINT_POSITIONS['hand'],
                'gripper2hand_config': GRIPPER_TO_HAND_CONFIG
            }
        else:
            self.config = robot_config
        
        # Motion control status
        self._motion_control_status = None
        self._motion_control_status_timestamp = 0

        # 运控状态缓存
        self._motion_control_status_buffer = deque(maxlen=100)  # 存储约1秒的数据(假设100Hz)
        self._motion_control_status_lock = threading.Lock()  # 用于线程安全访问
        self._latest_motion_control_status = None
        self._latest_motion_control_timestamp = 0

        self.node_ = agibotdds.Node("A2DMotionControl")
        self.qos = agibotdds.qos(depth=500)
        self.motion_control_status_topic = "/wbc/motion_control_status"
        self.motion_control_tracking_topic = "/wbc/model_predict"
        self.motion_control_retarget_topic = "/wbc/retarget"
        self.motion_stop_topic = "/wbc/motion_stop"
        self.motion_control_mode_topic = "/wbc/set_control_mode"
        self.end_control_topic = "/wbc/end_effector_pose_control"
        self.joint_control_topic = "/wbc/joint_position_control"
        
        self.motion_control_status_sub = self.node_.create_subscriber(
            self.motion_control_status_topic, MotionControlStatus, self.qos, self.motion_control_status_callback
        )
        self.motion_control_tracking_pub = self.node_.create_publisher(
            self.motion_control_tracking_topic, TrajectoryTrackingControl, self.qos
        )
        self.motion_control_retarget_pub = self.node_.create_publisher(
            self.motion_control_retarget_topic, ReactiveControl, self.qos
        )
        self.motion_stop_pub = self.node_.create_publisher(
            self.motion_stop_topic, MotionStop, self.qos
        )
        self.motion_control_mode_pub = self.node_.create_publisher(
            self.motion_control_mode_topic, SetControlMode, self.qos
        )
        self.end_control_pub = self.node_.create_publisher(
            self.end_control_topic, EndEffectorPoseControl, self.qos
        )
        self.joint_control_pub = self.node_.create_publisher(
            self.joint_control_topic, JointPositionControl, self.qos
        )
        
        
    def _xyzrpy_to_xyzquat(self, xyzrpy):
        """Convert xyz + rpy to xyz + quaternion"""
        xyz = xyzrpy[:3]
        quat = R.from_euler("xyz", xyzrpy[3:]).as_quat()
        quat = np.array(quat)
        xyzquat = np.concatenate([xyz, quat])
        return xyzquat

    def _homogeneous_mat_to_ros_pose(self, homogeneous_mat):
        """Convert homogeneous matrix to ROS Pose message"""
        rot = Rotation.from_matrix(homogeneous_mat[0:3, 0:3])
        quat = rot.as_quat()
        pose = Pose()
        pose.orientation.x = quat[0]
        pose.orientation.y = quat[1]
        pose.orientation.z = quat[2]
        pose.orientation.w = quat[3]
        return pose
    
    def _switch_control_type(self, control_type):
        """Switch control type string to control type id"""
        if control_type == "ABS_POSE":
            return CONTROL_TYPES['ABS_POSE']
        elif control_type == "DELTA_POSE":
            return CONTROL_TYPES['DELTA_POSE']
        elif control_type == "END_SPEED":
            return CONTROL_TYPES['END_SPEED']
        elif control_type == "ABS_JOINT":
            return CONTROL_TYPES['ABS_JOINT']
        elif control_type == "DELTA_JOINT":
            return CONTROL_TYPES['DELTA_JOINT']
        elif control_type == "JOINT_SPEED":
            return CONTROL_TYPES['JOINT_SPEED']
        elif control_type == "PASSIVE":
            return CONTROL_TYPES['PASSIVE']
        else:
            raise ValueError(f"Unsupported control type: {control_type}")

    def create_retarget_info(self, group_id, control_type, data, **kwargs):
        """Create a RetargetInfo message for various control types
        
        Args:
            group_id: Group ID for the control
            control_type: Control type (0=absolute pose, 1=relative pose, 2=end effector velocity, etc.)
            data: Control data (pose, joint positions, velocities, etc.)
            **kwargs: Additional arguments based on control type:
                - frame_id: Frame ID for the command (for end-effector control)
                - target_frame: Target frame name (for end-effector control)
                - ref_frame: Reference frame name (for end-effector control)
                - transform: Transform matrix (for end-effector control)
            
        Returns:
            RetargetInfo message or None if invalid parameters
        """
        info = RetargetInfo()
        info.group_id = group_id
        info.control_type = control_type
        
        # End-effector relative pose control
        if control_type == CONTROL_TYPES['DELTA_POSE'] or control_type == CONTROL_TYPES['ABS_POSE']:
            # Validate group ID
            if group_id not in [GROUP_IDS['left_arm'], GROUP_IDS['right_arm']]:
                print(f"Currently, only arm groups are supported for relative pose control")
                return None
            
            # Validate required parameters
            frame_id = kwargs.get('frame_id')
            target_frame = kwargs.get('target_frame')
            ref_frame = kwargs.get('ref_frame')
            transform = kwargs.get('transform')
            
            # Check if any required parameter is None
            if frame_id is None or target_frame is None or ref_frame is None or transform is None:
                print(f"Missing required parameters for DELTA_POSE control")
                return None
            
            info.frame_id = frame_id
            info.target_frame_names.append(target_frame)
            
            # Convert xyzrpy to pose
            pose = Pose()
            xyzquat = self._xyzrpy_to_xyzquat(data)
            pose.position.x = xyzquat[0]
            pose.position.y = xyzquat[1]
            pose.position.z = xyzquat[2]
            pose.orientation.x = xyzquat[3]
            pose.orientation.y = xyzquat[4]
            pose.orientation.z = xyzquat[5]
            pose.orientation.w = xyzquat[6]
            
            if control_type == CONTROL_TYPES['DELTA_POSE']:
                info.target_frame_poses_delta.append(pose)
            elif control_type == CONTROL_TYPES['ABS_POSE']:
                info.target_frame_poses.append(pose)
                
            info.reference_frame_names.append(ref_frame)
            info.reference_frame_poses.append(self._homogeneous_mat_to_ros_pose(transform))
        
        # End-effector velocity control
        elif control_type == CONTROL_TYPES['END_SPEED']:
            # Validate required parameters
            frame_id = kwargs.get('frame_id')
            target_frame = kwargs.get('target_frame')
            
            if not all([frame_id, target_frame]):
                print(f"Missing required parameters for END_SPEED control")
                return None
            
            info.frame_id = frame_id
            info.target_frame_names.append(target_frame)
            
            # Create twist message
            twist = Twist()
            if len(data) >= 6:
                twist.linear.x = data[0]
                twist.linear.y = data[1]
                twist.linear.z = data[2]
                twist.angular.x = data[3]
                twist.angular.y = data[4]
                twist.angular.z = data[5]
            else:
                # Handle partial specification
                twist.linear.x = data[0] if len(data) > 0 else 0.0
                twist.linear.y = data[1] if len(data) > 1 else 0.0
                twist.linear.z = data[2] if len(data) > 2 else 0.0
            
            info.target_frame_velocities.append(twist)
        
        # Absolute joint position control
        elif control_type == CONTROL_TYPES['ABS_JOINT']:
            info.target_joint_positions.extend(data)
        
        # Relative joint position control
        elif control_type == CONTROL_TYPES['DELTA_JOINT']:
            info.target_joint_positions_delta.extend(data)
        
        # Joint velocity control
        elif control_type == CONTROL_TYPES['JOINT_SPEED']:
            # Validate group ID for chassis
            if group_id == GROUP_IDS['chassis']:
                info.target_joint_velocities.extend(data)
            else:
                print(f"Currently, only chassis group is supported for joint speed control")
                return None
        
        # Passive control
        elif control_type == CONTROL_TYPES['PASSIVE']:
            # No additional data needed for passive control
            pass
        
        else:
            print(f"Unsupported control type: {control_type}")
            return None
        
        return info

    def create_reactive_control(self, infer_timestamp, robot_action, robot_link="base_link", lifetime=1):
        """Create reactive control command
        
        Args:
            infer_timestamp: Timestamp in nanoseconds
            robot_action: Action dictionary for reactive control
                - robot_action['part']['action_data']
                - robot_action['part']['control_type']
            robot_link: Link name of the robot
            lifetime: Lifetime of the reactive control in seconds
            
        Returns:
            ReactiveControl message
        """
        reactive_cmd = ReactiveControl()
        reactive_cmd.header.stamp.sec = infer_timestamp // 1000000000
        reactive_cmd.header.stamp.nanosec = infer_timestamp % 1000000000
        reactive_cmd.header.frame_id = robot_link
        reactive_cmd.lifetime = lifetime
        
        # Reference frames for arms
        ref_frames = [ARM_REFERENCE_FRAMES['left']['frame'], ARM_REFERENCE_FRAMES['right']['frame']]
        T_l = np.array(ARM_REFERENCE_FRAMES['left']['transform'])
        T_r = np.array(ARM_REFERENCE_FRAMES['right']['transform'])
        
        # Process each control group in the action
        if 'left_arm' in robot_action:
            # Check if we're dealing with end-effector pose, joint velocities, or end-effector velocity
            left_info = self.create_retarget_info(
                GROUP_IDS['left_arm'],
                self._switch_control_type(robot_action['left_arm']['control_type']),
                robot_action['left_arm']['action_data'],
                frame_id=robot_link,
                target_frame="arm_left_link7",
                ref_frame=ref_frames[0],
                transform=T_l
            )
            reactive_cmd.retarget_groups.append(left_info)
        
        if 'right_arm' in robot_action:
            # Similar logic for right arm
            right_info = self.create_retarget_info(
                GROUP_IDS['right_arm'],
                self._switch_control_type(robot_action['right_arm']['control_type']),
                robot_action['right_arm']['action_data'],
                frame_id=robot_link,
                target_frame="arm_right_link7",
                ref_frame=ref_frames[1],
                transform=T_r
            )
            reactive_cmd.retarget_groups.append(right_info)
        
        if 'head' in robot_action:
            # For head joint velocities
            head_yaw = self.create_retarget_info(
                GROUP_IDS['head_yaw'],
                self._switch_control_type(robot_action['head']['control_type']),
                [robot_action['head']['action_data'][0]]
            )
            head_pitch = self.create_retarget_info(
                GROUP_IDS['head_pitch'],
                self._switch_control_type(robot_action['head']['control_type']),
                [robot_action['head']['action_data'][1]]
            )
            reactive_cmd.retarget_groups.extend([head_yaw, head_pitch])
        
        if 'waist' in robot_action:
            # For waist joint velocities
            waist_pitch = self.create_retarget_info(
                GROUP_IDS['waist_pitch'],
                self._switch_control_type(robot_action['waist']['control_type']),
                [robot_action['waist']['action_data'][0]]
            )
            waist_lift = self.create_retarget_info(
                GROUP_IDS['waist_lift'],
                self._switch_control_type(robot_action['waist']['control_type']),
                [robot_action['waist']['action_data'][1] / 100.0]
            )
            reactive_cmd.retarget_groups.extend([waist_pitch, waist_lift])
        
        if 'gripper' in robot_action or 'hand' in robot_action:
            # For gripper control
            left_gripper = self.create_retarget_info(
                GROUP_IDS['left_tool'],
                self._switch_control_type(robot_action['gripper']['control_type']),
                [robot_action['gripper']['action_data'][0]]
            )
            right_gripper = self.create_retarget_info(
                GROUP_IDS['right_tool'],
                self._switch_control_type(robot_action['gripper']['control_type']),
                [robot_action['gripper']['action_data'][1]]
            )
            reactive_cmd.retarget_groups.extend([left_gripper, right_gripper])
        
        if 'hand' in robot_action:
            # For hand control
            left_hand = self.create_retarget_info(
                GROUP_IDS['left_tool'],
                self._switch_control_type(robot_action['hand']['control_type']),
                robot_action['hand']['action_data'][:6]
            )
            right_hand = self.create_retarget_info(
                GROUP_IDS['right_tool'],
                self._switch_control_type(robot_action['hand']['control_type']),
                robot_action['hand']['action_data'][6:]
            )
            reactive_cmd.retarget_groups.extend([left_hand, right_hand])
        
        if 'chassis' in robot_action:
            # For chassis velocity control
            chassis_info = self.create_retarget_info(
                GROUP_IDS['chassis'],
                self._switch_control_type(robot_action['chassis']['control_type']),
                robot_action['chassis']['action_data']
            )
            reactive_cmd.retarget_groups.append(chassis_info)
        
        self.motion_control_retarget_pub.publish(reactive_cmd)

    def create_trajectory_tracking(self, infer_timestamp, robot_states, robot_actions, 
                                   robot_link="base_link", trajectory_reference_time=1.0):
        """Create trajectory tracking control command
        
        Args:
            infer_timestamp: Timestamp in nanoseconds
            robot_states: Current robot joint states by group
            robot_actions: List of action dictionaries for trajectory
                - robot_action['part']['action_data']
                - robot_action['part']['robot_link']
                - robot_action['part']['control_type']
            robot_link: Link name of the robot
            trajectory_reference_time: Reference time for trajectory
            
        Returns:
            TrajectoryTrackingControl message
        """
        tracking_cmd = TrajectoryTrackingControl()
        tracking_cmd.header.stamp.sec = infer_timestamp // 1000000000
        tracking_cmd.header.stamp.nanosec = infer_timestamp % 1000000000
        tracking_cmd.header.frame_id = robot_link
        tracking_cmd.trajectory_reference_time = trajectory_reference_time

        # Set current joint states
        joint_names = []
        joint_states = []
        for group in ['waist', 'head', 'arm', 'chassis', 'gripper', 'hand']:
            if group in robot_states:
                if group == 'waist':
                    joint_names.extend(self.config['waist_joint_names'])
                    joint_states.extend(robot_states['waist'])
                elif group == 'head':
                    joint_names.extend(self.config['head_joint_names'])
                    joint_states.extend(robot_states['head'])
                elif group == 'arm':
                    joint_names.extend(self.config['arm_joint_names'])
                    joint_states.extend(robot_states['arm'])
                elif group == 'gripper':
                    joint_names.extend(self.config['gripper_joint_names'])
                    joint_states.extend(robot_states['gripper'])
                elif group == 'hand':
                    joint_names.extend(self.config['hand_joint_names'])
                    joint_states.extend(robot_states['hand'])
                elif group == 'chassis':
                    joint_names.extend(self.config['chassis_joint_names'])
                    joint_states.extend(robot_states['chassis'])
        
        tracking_cmd.joint_names.extend(joint_names)
        tracking_cmd.joint_states.extend(joint_states)

        # Reference frames for arms
        ref_frames = [ARM_REFERENCE_FRAMES['left']['frame'], ARM_REFERENCE_FRAMES['right']['frame']]
        T_l = np.array(ARM_REFERENCE_FRAMES['left']['transform'])
        T_r = np.array(ARM_REFERENCE_FRAMES['right']['transform'])

        # Create trajectory
        for action in robot_actions:
            retarget_array = RetargetInfoArray()
            
            # Process each control group
            if 'left_arm' in action:
                left_info = self.create_retarget_info(
                    GROUP_IDS['left_arm'],
                    self._switch_control_type(action['left_arm']['control_type']),
                    action['left_arm']['action_data'],
                    frame_id=robot_link,
                    target_frame="arm_left_link7",
                    ref_frame=ref_frames[0],
                    transform=T_l
                )
                retarget_array.retarget_infos.append(left_info)
            
            if 'right_arm' in action:
                right_info = self.create_retarget_info(
                    GROUP_IDS['right_arm'],
                    self._switch_control_type(action['right_arm']['control_type']),
                    action['right_arm']['action_data'],
                    frame_id=robot_link,
                    target_frame="arm_right_link7",
                    ref_frame=ref_frames[1],
                    transform=T_r
                )
                retarget_array.retarget_infos.append(right_info)
            
            if 'head' in action:
                head_yaw = self.create_retarget_info(
                    GROUP_IDS['head_yaw'],
                    self._switch_control_type(action['head']['control_type']),
                    [action['head']['action_data'][0]]
                )
                head_pitch = self.create_retarget_info(
                    GROUP_IDS['head_pitch'],
                    self._switch_control_type(action['head']['control_type']),
                    [action['head']['action_data'][1]]
                )
                retarget_array.retarget_infos.extend([head_yaw, head_pitch])

            if 'waist' in action:
                waist_pitch = self.create_retarget_info(
                    GROUP_IDS['waist_pitch'],
                    self._switch_control_type(action['waist']['control_type']),
                    [action['waist']['action_data'][0]]
                )
                waist_lift = self.create_retarget_info(
                    GROUP_IDS['waist_lift'],
                    self._switch_control_type(action['waist']['control_type']),
                    [action['waist']['action_data'][1] / 100.0]
                )
                retarget_array.retarget_infos.extend([waist_pitch, waist_lift])

            if 'gripper' in action:
                left_gripper = self.create_retarget_info(
                    GROUP_IDS['left_tool'],
                    self._switch_control_type(action['gripper']['control_type']),
                    [action['gripper']['action_data'][0]]
                )
                right_gripper = self.create_retarget_info(
                    GROUP_IDS['right_tool'],
                    self._switch_control_type(action['gripper']['control_type']),
                    [action['gripper']['action_data'][1]]
                )
                retarget_array.retarget_infos.extend([left_gripper, right_gripper])
            
            if 'hand' in action:
                left_hand = self.create_retarget_info(
                    GROUP_IDS['left_tool'],
                    self._switch_control_type(action['hand']['control_type']),
                    action['hand']['action_data'][:6]
                )
                right_hand = self.create_retarget_info(
                    GROUP_IDS['right_tool'],
                    self._switch_control_type(action['hand']['control_type']),
                    action['hand']['action_data'][6:]
                )
                retarget_array.retarget_infos.extend([left_hand, right_hand])

            if 'chassis' in action:
                chassis_info = self.create_retarget_info(
                    GROUP_IDS['chassis'],
                    self._switch_control_type(action['chassis']['control_type']),
                    action['chassis']['action_data']
                )
                retarget_array.retarget_infos.append(chassis_info)

            tracking_cmd.retarget_groups_trajectory.append(retarget_array)

        self.motion_control_tracking_pub.publish(tracking_cmd)

    def motion_control_status_callback(self, msg):
        """处理运控状态回调，存储到缓冲区
        
        Args:
            msg: MotionControlStatus消息
        """
        timestamp = msg.header.stamp.sec * 1000000000 + msg.header.stamp.nanosec
        
        with self._motion_control_status_lock:
            # 存储到缓冲区
            self._motion_control_status_buffer.append((timestamp, msg))
            
            # 更新最新状态
            self._latest_motion_control_status = msg
            self._latest_motion_control_timestamp = timestamp
            
            # 清理超过1秒的数据
            current_time = time.time_ns()
            while (len(self._motion_control_status_buffer) > 1 and 
                   current_time - self._motion_control_status_buffer[0][0] > 1000000000):
                self._motion_control_status_buffer.popleft()

    def get_motion_control_status(self, timestamp=None):
        """获取运控状态信息
        
        Args:
            timestamp: 可选的时间戳(纳秒)，如果提供则返回最接近该时间戳的状态
                      如果不提供则返回最新状态
        
        Returns:
            包含运控状态信息的字典，如果没有状态则返回None
        """
        with self._motion_control_status_lock:
            if timestamp is None:
                # 返回最新状态
                status_msg = self._latest_motion_control_status
                status_timestamp = self._latest_motion_control_timestamp
            else:
                # 查找最接近时间戳的状态
                if not self._motion_control_status_buffer:
                    return None
                
                # 初始化为第一个元素
                closest_msg = self._motion_control_status_buffer[0][1]
                closest_timestamp = self._motion_control_status_buffer[0][0]
                min_diff = abs(timestamp - closest_timestamp)
                
                # 遍历缓冲区查找最接近的
                for ts, msg in self._motion_control_status_buffer:
                    diff = abs(timestamp - ts)
                    if diff < min_diff:
                        min_diff = diff
                        closest_msg = msg
                        closest_timestamp = ts
                
                status_msg = closest_msg
                status_timestamp = closest_timestamp
            
            # 如果没有找到状态
            if status_msg is None:
                return None
        
        # 创建基本状态信息
        status = {
            'timestamp': status_timestamp,
            'mode': {
                'value': status_msg.mode,
                'name': self._get_mode_name(status_msg.mode)
            },
            'error': {
                'code': status_msg.error_code,
                'message': status_msg.error_msg,
                'has_error': status_msg.error_code != 0
            },
            'frames': {},
            'collisions': []
        }
        
        # 处理帧位姿
        for i, frame_name in enumerate(status_msg.frame_names):
            if i < len(status_msg.frame_poses):
                pose = status_msg.frame_poses[i]
                
                # 存储位置和四元数方向
                position = {
                    'x': pose.position.x,
                    'y': pose.position.y,
                    'z': pose.position.z
                }
                
                orientation = {
                    'x': pose.orientation.x,
                    'y': pose.orientation.y,
                    'z': pose.orientation.z,
                    'w': pose.orientation.w
                }
                
                # 将四元数转换为欧拉角
                quat = [pose.orientation.x, pose.orientation.y, 
                       pose.orientation.z, pose.orientation.w]
                try:
                    euler = R.from_quat(quat).as_euler('xyz')
                    euler_dict = {
                        'roll': euler[0],
                        'pitch': euler[1],
                        'yaw': euler[2]
                    }
                except:
                    euler_dict = {
                        'roll': 0.0,
                        'pitch': 0.0,
                        'yaw': 0.0
                    }
                
                # 存储帧信息
                status['frames'][frame_name] = {
                    'position': position,
                    'orientation': {
                        'quaternion': orientation,
                        'euler': euler_dict
                    }
                }
                
                # 添加xyzrpy格式方便使用
                status['frames'][frame_name]['xyzrpy'] = [
                    position['x'], position['y'], position['z'],
                    euler_dict['roll'], euler_dict['pitch'], euler_dict['yaw']
                ]
        
        # 处理碰撞对
        for i in range(min(len(status_msg.collision_pairs_1), 
                          len(status_msg.collision_pairs_2))):
            status['collisions'].append({
                'frame1': status_msg.collision_pairs_1[i],
                'frame2': status_msg.collision_pairs_2[i]
            })
        
        return status

    def _get_mode_name(self, mode):
        """获取运控模式名称
        
        Args:
            mode: 模式值 (0=STOP, 1=SERVO, 2=PLANNING)
            
        Returns:
            模式名称字符串
        """
        mode_names = {
            0: 'STOP',
            1: 'SERVO',
            2: 'PLANNING'
        }
        return mode_names.get(mode, f'UNKNOWN({mode})')
    
    def set_motion_stop(self):
        """设置运控停止"""
        stop_msg = MotionStop()
        #INPUT_GDK=54
        stop_msg.input_type = 54
        self.motion_stop_pub.publish(stop_msg)

    def set_motion_control_mode(self, mode):
        """设置运控模式"""
        """
        mode: 0=STOP, 1=SERVO, 2=PLANNING
        """
        mode_msg = SetControlMode()
        #INPUT_GDK=54
        mode_msg.input_type = 54
        mode_msg.control_mode = mode
        self.motion_control_mode_pub.publish(mode_msg)
    
    def set_end_effector_pose_control(self, lifetime, control_group, left_pose=None, right_pose=None):
        """
           control_group: 控制组，可以是单个控制组，也可以是多个控制组
           left_pose: 左末端位姿，可以为None
           right_pose: 右末端位姿，可以为None
    
        """

        """设置末端位姿控制"""
        mc_control_groups = 0
        for control_name in control_group:
            if control_name not in POSE_GROUP_IDS:
                raise ValueError(f"control_name must be in {POSE_GROUP_IDS.keys()}")
            mc_control_groups |= POSE_GROUP_IDS[control_name]

        control_msg = EndEffectorPoseControl()
        control_msg.lifetime = lifetime
        control_msg.control_group = mc_control_groups
        
        if left_pose is not None:
            control_msg.left_end_effector_pose.position.x = left_pose['x']
            control_msg.left_end_effector_pose.position.y = left_pose['y']
            control_msg.left_end_effector_pose.position.z = left_pose['z']
            control_msg.left_end_effector_pose.orientation.x = left_pose['qx']
            control_msg.left_end_effector_pose.orientation.y = left_pose['qy']
            control_msg.left_end_effector_pose.orientation.z = left_pose['qz']
            control_msg.left_end_effector_pose.orientation.w = left_pose['qw']

        if right_pose is not None:
            control_msg.right_end_effector_pose.position.x = right_pose['x']
            control_msg.right_end_effector_pose.position.y = right_pose['y']
            control_msg.right_end_effector_pose.position.z = right_pose['z']
            control_msg.right_end_effector_pose.orientation.x = right_pose['qx']
            control_msg.right_end_effector_pose.orientation.y = right_pose['qy']
            control_msg.right_end_effector_pose.orientation.z = right_pose['qz']
            control_msg.right_end_effector_pose.orientation.w = right_pose['qw']

        self.end_control_pub.publish(control_msg)

    def set_joint_position_control(self, lifetime, joint_group):
        """
            joint_group是dict
            {
                'head_yaw': [0.0],
                'head_pitch': [0.0],
                'waist_pitch': [0.0],
                'waist_lift': [0.0],
                'left_tool': [0.0],
                'right_tool': [0.0],
                'left_arm': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                'right_arm': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
            }
            里面的key可以为空
        """
        """设置关节位置控制"""
        control_group = 0
        for control_name, positions in joint_group.items():
            if control_name not in JOINT_GROUP_IDS:
                raise ValueError(f"control_name must be in {JOINT_GROUP_IDS.keys()}")
            control_group |= JOINT_GROUP_IDS[control_name]
        
        control_msg = JointPositionControl()
        control_msg.lifetime = lifetime
        control_msg.control_group = control_group

        if 'head_yaw' in joint_group:
            control_msg.head_yaw_joint_position = joint_group['head_yaw']
        if 'head_pitch' in joint_group:
            control_msg.head_pitch_joint_position = joint_group['head_pitch']
        if 'waist_pitch' in joint_group:
            control_msg.waist_pitch_joint_position = joint_group['waist_pitch']
        if 'waist_lift' in joint_group:
            control_msg.waist_lift_joint_position = joint_group['waist_lift']
        if 'left_tool' in joint_group:
            del control_msg.left_tool_joint_positions[:]
            control_msg.left_tool_joint_positions.extend(joint_group['left_tool'])
        if 'right_tool' in joint_group:
            del control_msg.right_tool_joint_positions[:]
            control_msg.right_tool_joint_positions.extend(joint_group['right_tool'])
        if 'left_arm' in joint_group:
            del control_msg.left_arm_joint_positions[:]
            control_msg.left_arm_joint_positions.extend(joint_group['left_arm'])
        if 'right_arm' in joint_group:
            del control_msg.right_arm_joint_positions[:]
            control_msg.right_arm_joint_positions.extend(joint_group['right_arm'])
        
        self.joint_control_pub.publish(control_msg)
        
        
        
        
