# Motion control configuration

# Default joint positions
DEFAULT_JOINT_POSITIONS = {
    'waist': [0.523, 0.279],  # [waist_pitch, waist_lift]
    'head': [0.000, 0.506],   # [head_yaw, head_pitch]
    'arm': [
        0.881, 0.671, -0.5369, -1.8702, 0.8555, 0.6907, 1.1398,  # left arm
        -0.881, -0.671, 0.5369, 1.8702, -0.8555, -0.6907, -1.1398  # right arm
    ],
    'hand': [
        0.881, 0.671, -0.5369, -1.8702, 0.8555, 0.6907,  # left hand
        -0.881, -0.671, 0.5369, 1.8702, -0.8555, -0.6907,  # right hand
    ]
}

# Joint names
JOINT_NAMES = {
    'waist': ['joint_body_pitch', 'joint_lift_body'],
    'head': ['joint_head_yaw', 'joint_head_pitch'],
    'arm': [
        'Joint1_l', 'Joint2_l', 'Joint3_l', 'Joint4_l', 'Joint5_l', 'Joint6_l', 'Joint7_l',
        'Joint1_r', 'Joint2_r', 'Joint3_r', 'Joint4_r', 'Joint5_r', 'Joint6_r', 'Joint7_r'
    ],
    'hand': [
        # Left
        'left_thumb_flex', 'left_index_flex', 'left_middle_flex',
        'left_ring_flex', 'left_little_flex', 'left_thumb_rot',
        # Right
        'right_thumb_flex', 'right_index_flex', 'right_middle_flex',
        'right_ring_flex', 'right_little_flex', 'right_thumb_rot'
    ],
    'gripper': ['left', 'right']
}

# Motion limits
MOTION_LIMITS = {
    'arm': {
        'max_velocity': 2.0,
        'max_acceleration': 1.0,
        'max_jerk': 5.0
    }
}

# Reference frames for arms
ARM_REFERENCE_FRAMES = {
    'left': {
        'frame': 'arm_left_link3',
        'transform': [[1, 0, 0, 0], [0, 0, 1, 0], [0, -1, 0, 0], [0, 0, 0, 1]]
    },
    'right': {
        'frame': 'arm_right_link3',
        'transform': [[-1, 0, 0, 0], [0, 0, -1, 0], [0, -1, 0, 0], [0, 0, 0, 1]]
    }
}

# Group IDs for different control groups
GROUP_IDS = {
    'head_yaw': 0,
    'head_pitch': 1,
    'left_arm': 2,
    'right_arm': 3,
    'left_tool': 4,
    'right_tool': 5,
    'waist_lift': 6,
    'waist_pitch': 7,
    'chassis': 8
}

# Control types
CONTROL_TYPES = {
    'ABS_POSE': 0,
    'DELTA_POSE': 1,
    'END_SPEED': 2,
    'ABS_JOINT': 3,
    'DELTA_JOINT': 4,
    'JOINT_SPEED': 5,
    'PASSIVE': 6
}

# Gripper to hand mapping configuration
GRIPPER_TO_HAND_CONFIG = {
    'thumb_flex': {'min': 3500.0, 'max': 250.0},
    'index_flex': {'min': 17000.0, 'max': 10000.0},
    'middle_flex': {'min': 17000.0, 'max': 10000.0},
    'ring_flex': {'min': 17000.0, 'max': 10000.0},
    'little_flex': {'min': 17000.0, 'max': 10000.0},
    'thumb_rot': 4000.0
}

"""
uint32 GROUP_HEAD_YAW = 1
uint32 GROUP_HEAD_PITCH = 2
uint32 GROUP_LEFT_ARM = 4
uint32 GROUP_RIGHT_ARM = 8
uint32 GROUP_WAIST_LIFT = 16
uint32 GROUP_WAIST_PITCH = 32
uint32 GROUP_LEFT_TOOL = 128 # 手或夹爪,mc根据配置
uint32 GROUP_RIGHT_TOOL = 256 # 手或夹爪,mc根据配置
"""
JOINT_GROUP_IDS = {
    'head_yaw': 1,
    'head_pitch': 2,
    'left_arm': 4,
    'right_arm': 8,
    'waist_lift': 16,
    'waist_pitch': 32,
    'left_tool': 128,
    'right_tool': 256
}

"""
uint32 GROUP_LEFT_ARM = 4
uint32 GROUP_RIGHT_ARM = 8
uint32 GROUP_DUAL_ARM = 12

uint32 GROUP_LEFT_ARM_WAIST_LIFT = 20
uint32 GROUP_LEFT_ARM_WAIST_PITCH = 36
uint32 GROUP_LEFT_ARM_WAIST = 52
uint32 GROUP_RIGHT_ARM_WAIST_LIFT = 24
uint32 GROUP_RIGHT_ARM_WAIST_PITCH = 40
uint32 GROUP_RIGHT_ARM_WAIST = 56
uint32 GROUP_DUAL_ARM_WAIST_LIFT = 28
uint32 GROUP_DUAL_ARM_WAIST_PITCH = 44
uint32 GROUP_DUAL_ARM_WAIST = 60

"""
POSE_GROUP_IDS = {
    'left_arm': 4,
    'right_arm': 8,
    'dual_arm': 12,
    'left_arm_waist_lift': 20,
    'left_arm_waist_pitch': 36,
    'left_arm_waist': 52,
    'right_arm_waist_lift': 24,
    'right_arm_waist_pitch': 40,
    'right_arm_waist': 56,
    'dual_arm_waist_lift': 28,
    'dual_arm_waist_pitch': 44,
    'dual_arm_waist': 60
}