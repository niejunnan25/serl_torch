#! /usr/bin/env python3
# -*- coding: utf-8 -*-
import time

from cosine_bus.agibotdds_py3 import agibotdds

from std_msgs_pb.msg.Header_pb2 import Header
from std_srvs_pb.srv.SetBool_pb2 import SetBool_Request as SetBoolRequest, SetBool_Response as SetBoolResponse
from std_srvs_pb.srv.Trigger_pb2 import Trigger_Request as TriggerRequest, Trigger_Response as TriggerResponse

from genie_msgs_pb.msg.AGVInfo_pb2 import AGVInfo
from genie_msgs_pb.msg.SetAGVInfo_pb2 import SetAGVInfo
from genie_msgs_pb.msg.Position_pb2 import Position
from genie_msgs_pb.msg.BatteryStatus_pb2 import BatteryStatus
from genie_msgs_pb.msg.AGVTaskState_pb2 import AGVTaskState

from genie_msgs_pb.srv.AGVModeControl_pb2 import AGVModeControl_Request as AGVModeControlRequest, AGVModeControl_Response as AGVModeControlResponse
from genie_msgs_pb.srv.AGVMappingControl_pb2 import AGVMappingControl_Request as AGVMappingControlRequest, AGVMappingControl_Response as AGVMappingControlResponse
from genie_msgs_pb.srv.AGVGetMap_pb2 import AGVGetMap_Request as AGVGetMapRequest, AGVGetMap_Response as AGVGetMapResponse
from genie_msgs_pb.srv.AGVMapList_pb2 import AGVMapList_Request as AGVMapListRequest, AGVMapList_Response as AGVMapListResponse
from genie_msgs_pb.srv.AGVMapDelete_pb2 import AGVMapDelete_Request as AGVMapDeleteRequest, AGVMapDelete_Response as AGVMapDeleteResponse
from genie_msgs_pb.srv.AGVSwitchMap_pb2 import AGVSwitchMap_Request as AGVSwitchMapRequest, AGVSwitchMap_Response as AGVSwitchMapResponse
from genie_msgs_pb.srv.NavigatePose_pb2 import NavigatePose_Request as NavigationControlRequest, NavigatePose_Response as NavigationControlResponse
from genie_msgs_pb.srv.ReLocalization_pb2 import ReLocalization_Request as ReLocalizationRequest, ReLocalization_Response as ReLocalizationResponse
from genie_msgs_pb.srv.AGVCollisionLevel_pb2 import AGVCollisionLevel_Request as AGVCollisionLevelRequest, AGVCollisionLevel_Response as AGVCollisionLevelResponse
from genie_msgs_pb.srv.ArmCollisionLevel_pb2 import ArmCollisionLevel_Request as ArmCollisionLevelRequest, ArmCollisionLevel_Response as ArmCollisionLevelResponse
from genie_msgs_pb.srv.ArmGetCollisionLevel_pb2 import ArmGetCollisionLevel_Request as ArmGetCollisionLevelRequest, ArmGetCollisionLevel_Response as ArmGetCollisionLevelResponse
from nav_msgs_pb.msg.OccupancyGrid_pb2 import OccupancyGrid

class SlamCore():
    def __init__(
            self,
            switch_nav_mode_topic='/hal/switch_nav_mode',
            mapping_control_topic='/hal/slam/mapping_control',
            pub_map_topic = '/hal/map',
            get_map_topic = '/hal/map/get_map',
            map_list_topic = '/hal/map/map_list',
            delete_map_topic = '/hal/map/remove_map',
            switch_map_topic = '/hal/map/switch_map',
            navigate_topic='/hal/nav/navigate_to_pose',
            move_to_relative_topic = '/hal/nav/move_relative',
            reloc_topic = '/hal/loc/relocalize',
            set_agv_col_level_topic = '/hal/nav/collision',
            set_agv_col_ctrl_topic = '/hal/nav/collision_override',
            set_arm_col_level_topic = '/hal/collision_level',
            get_arm_col_level_topic = '/hal/collision_level_get',
            pause_walk_topic = '/hal/nav/pause_walk',
            set_chassis_info_topic = '/hal/set_chassis_info',
            get_chassis_info_topic = '/hal/chassis_info',
            chassis_position_topic = '/hal/position',
            chassis_battery_status_topic = '/hal/batt_state',
            ):
        self.node_ = agibotdds.Node("A2DRosSlam")
        self.qos = agibotdds.qos(depth=500)
        
        self._cur_map = OccupancyGrid()

        self._chassis_info = AGVInfo()
        self._chassis_position = Position()
        self._chassis_battery_status = BatteryStatus()

        self._switch_nav_mode_client = self.node_.create_client(
            switch_nav_mode_topic, AGVModeControlRequest, AGVModeControlResponse
        )
        self._mapping_control_client = self.node_.create_client(
            mapping_control_topic, AGVMappingControlRequest, AGVMappingControlResponse
        )
        self._get_map_client = self.node_.create_client(
            get_map_topic, AGVGetMapRequest, AGVGetMapResponse
        )
        self._map_list_client = self.node_.create_client(
            map_list_topic, AGVMapListRequest, AGVMapListResponse
        )
        self._delete_map_client = self.node_.create_client(
            delete_map_topic, AGVMapDeleteRequest, AGVGetMapResponse
        )
        self._switch_map_client = self.node_.create_client(
            switch_map_topic, AGVSwitchMapRequest, AGVSwitchMapResponse
        )
        self._navigate_to_pose_client = self.node_.create_client(
            navigate_topic, NavigationControlRequest, NavigationControlResponse
        )
        self._move_to_relative_client = self.node_.create_client(
            move_to_relative_topic, NavigationControlRequest, NavigationControlResponse
        )
        self._reloc_client = self.node_.create_client(
            reloc_topic, ReLocalizationRequest, ReLocalizationResponse
        )
        self._set_agv_col_level_client = self.node_.create_client(
            set_agv_col_level_topic, AGVCollisionLevelRequest, AGVCollisionLevelResponse
        )
        self._set_agv_col_ctrl_client = self.node_.create_client(
            set_agv_col_ctrl_topic, SetBoolRequest, SetBoolResponse
        )
        self._set_arm_col_level_client = self.node_.create_client(
            set_arm_col_level_topic, ArmCollisionLevelRequest, ArmCollisionLevelResponse 
        )
        self._get_arm_col_level_client = self.node_.create_client(
            get_arm_col_level_topic, ArmGetCollisionLevelRequest, ArmGetCollisionLevelResponse
        )
        self._map_sub = self.node_.create_subscriber(
            pub_map_topic, OccupancyGrid, self.qos, self.get_map_callback
        )
        self._pause_walk_client = self.node_.create_client(
            pause_walk_topic, SetBoolRequest, SetBoolResponse
        )
        self._set_chassis_info_pub = self.node_.create_publisher(
            set_chassis_info_topic, SetAGVInfo, self.qos
        )
        self._get_chassis_info_sub = self.node_.create_subscriber(
            get_chassis_info_topic, AGVInfo, self.qos, self.get_chassis_info_callback
        )
        self._chassis_position_sub = self.node_.create_subscriber(
            chassis_position_topic, Position, self.qos, self.get_chassis_position_callback
        )
        self._chassis_battery_status_sub = self.node_.create_subscriber(
            chassis_battery_status_topic, BatteryStatus, self.qos, self.get_chassis_battery_status_callback
        )
    
    def switch_nav_mode(self, mode):
        request = AGVModeControlRequest()
        request.mode = mode
        response = self._switch_nav_mode_client.send_request(request)
        return response
    
    def mapping_control(self, control_code, save_map=False, map_name="default"):
        request = AGVMappingControlRequest()
        request.control = control_code
        request.save_map = save_map
        request.map_name = map_name
        response = self._mapping_control_client.send_request(request)
        return response
    
    def get_map(self, map_id):
        request = AGVGetMapRequest()
        request.map_id = map_id
        response = self._get_map_client.send_request(request)
        return response
    
    def get_map_list(self):
        request = AGVMapListRequest()
        request.header.stamp.sec = int(time.time())
        request.header.stamp.nanosec = 0
        request.header.frame_id = "get_arm_col_level"
        response = self._map_list_client.send_request(request)
        return response
    
    def delete_map(self, map_id):
        request = AGVMapDeleteRequest()
        request.map_id = map_id
        response = self._delete_map_client.send_request(request)
        return response
    
    def switch_map(self, map_id):
        request = AGVSwitchMapRequest()
        request.map_id = map_id
        response = self._switch_map_client.send_request(request)
        return response

    def navigate_to_pose(self, x, y, theta):
        request = NavigationControlRequest()
        request.x = x
        request.y = y
        request.theta = theta
        response = self._navigate_to_pose_client.send_request(request)
        return response
    
    def move_to_relative(self, x, y, theta):
        request = NavigationControlRequest()
        request.x = x
        request.y = y
        request.theta = theta
        response = self._move_to_relative_client.send_request(request)
        return response
    
    def relocation(self, x, y, theta):
        request = ReLocalizationRequest()
        request.x = x
        request.y = y
        request.theta = theta
        response = self._reloc_client.send_request(request)
        return response
    
    def set_agv_col_level(self, level):
        request = AGVCollisionLevelRequest()
        request.collision_level = level
        response = self._set_agv_col_level_client.send_request(request)
        return response
    
    def set_agv_col_ctrl(self, ctrl=False):
        request = SetBoolRequest()
        request.data = ctrl
        response = self._set_agv_col_ctrl_client.send_request(request)
        return response
    
    def set_arm_col_level(self, level):
        request = ArmCollisionLevelRequest()
        request.level = level
        response = self._set_arm_col_level_client.send_request(request)
        return response
    
    def get_arm_col_level(self):
        request = ArmGetCollisionLevelRequest()
        request.header.stamp.sec = int(time.time())
        request.header.stamp.nanosec = 0
        request.header.frame_id = "get_arm_col_level"
        response = self._get_arm_col_level_client.send_request(request)
        return response 
    
    def get_map_callback(self, msg):
        self._cur_map.info.resolution = msg.info.resolution
        self._cur_map.info.width = msg.info.width
        self._cur_map.info.height = msg.info.height
        self._cur_map.info.origin.position.x = msg.info.origin.position.x
        self._cur_map.info.origin.position.y = msg.info.origin.position.y
        self._cur_map.info.origin.orientation.w = msg.info.origin.orientation.w
        self._cur_map.data = msg.data[:]
        self._cur_map.header.stamp.sec = msg.header.stamp.sec
        self._cur_map.header.stamp.nanosec = msg.header.stamp.nanosec
    
    def get_latest_map(self):
        return self._cur_map.info, self._cur_map.data, self._cur_map.header.stamp.sec * 1e9 + self._cur_map.header.stamp.nanosec
    
    def pause_walk(self, pause=False):
        request = SetBoolRequest()
        request.data = pause
        response = self._pause_walk_client.send_request(request)
        return response
    
    def set_chassis_info(self, max_linear_speed, max_angular_speed, min_collision_distance):
        agv_info = SetAGVInfo()
        agv_info.set_max_linear_speed = max_linear_speed
        agv_info.set_max_angular_speed = max_angular_speed
        agv_info.set_min_collision_distance = min_collision_distance
        self._set_chassis_info_pub.publish(agv_info)
    
    def get_chassis_info_callback(self, msg):
        self._chassis_info.header.stamp.sec = msg.header.stamp.sec
        self._chassis_info.header.stamp.nanosec = msg.header.stamp.nanosec
        self._chassis_info.max_linear_speed = msg.max_linear_speed
        self._chassis_info.max_angular_speed = msg.max_angular_speed
        self._chassis_info.min_collision_distance = msg.min_collision_distance

    def get_chassis_info(self):
        chassis_info = {}
        chassis_info['max_linear_speed'] = self._chassis_info.max_linear_speed
        chassis_info['max_angular_speed'] = self._chassis_info.max_angular_speed
        chassis_info['min_collision_distance'] = self._chassis_info.min_collision_distance
        return chassis_info, self._chassis_info.header.stamp.sec * 1e9 + self._chassis_info.header.stamp.nanosec
    
    """
    optional float                          position_conf  = 124496863;
  optional float                          agv_pos_x      = 176305748;
  optional float                          agv_pos_y      = 495274407;
  optional float                          agv_pos_z      =  76319661;
  optional float                          agv_angle      =  66904363;
  optional float                          odom_x         =  73783734;
  optional float                          odom_y         = 325254765;
  optional float                          odom_z         = 174833355;
  optional float                          odom_angle     = 439907344;
  optional float                          linear_speed   = 396659941;
  optional float                          angular_speed  = 499165955;
  optional float                          acc_x          =  42945669;
  optional float                          acc_y          = 361238624;
  optional float                          acc_z          = 209809754;
  optional float                          gyro_x         = 296835030;
  optional float                          gyro_y         = 112626773;
  optional float                          gyro_z         = 532622599;
  optional float                          roll           = 246758048;
  optional float                          pitch          = 127911595;
  optional float                          yaw            = 384186525;
  //底盘电机状态
  repeated genie_msgs.msg.pb.MotorState   motor_states   = 160732956;

  //AGV任务状态
  optional genie_msgs.msg.pb.AGVTaskState agv_task_state = 342191022;
  """
    def get_chassis_position_callback(self, msg):
        self._chassis_position.header.stamp.sec = msg.header.stamp.sec
        self._chassis_position.header.stamp.nanosec = msg.header.stamp.nanosec
        self._chassis_position.agv_status = msg.agv_status
        self._chassis_position.position_conf = msg.position_conf
        self._chassis_position.agv_pos_x = msg.agv_pos_x
        self._chassis_position.agv_pos_y = msg.agv_pos_y
        self._chassis_position.agv_pos_z = msg.agv_pos_z
        self._chassis_position.agv_angle = msg.agv_angle
        self._chassis_position.odom_x = msg.odom_x
        self._chassis_position.odom_y = msg.odom_y
        self._chassis_position.odom_z = msg.odom_z
        self._chassis_position.odom_angle = msg.odom_angle
        self._chassis_position.linear_speed = msg.linear_speed
        self._chassis_position.angular_speed = msg.angular_speed
        self._chassis_position.acc_x = msg.acc_x
        self._chassis_position.acc_y = msg.acc_y
        self._chassis_position.acc_z = msg.acc_z
        self._chassis_position.gyro_x = msg.gyro_x
        self._chassis_position.gyro_y = msg.gyro_y
        self._chassis_position.gyro_z = msg.gyro_z
        self._chassis_position.roll = msg.roll
        self._chassis_position.pitch = msg.pitch
        self._chassis_position.yaw = msg.yaw
        del self._chassis_position.motor_states[:]
        for motor_state in msg.motor_states:
            self._chassis_position.motor_states.append(motor_state)
        self._chassis_position.agv_task_state.CopyFrom(msg.agv_task_state)
        
    def get_chassis_position(self):
        chassis_position = {}
        chassis_position['agv_status'] = self._chassis_position.agv_status
        chassis_position['position_conf'] = self._chassis_position.position_conf
        chassis_position['agv_pos_x'] = self._chassis_position.agv_pos_x
        chassis_position['agv_pos_y'] = self._chassis_position.agv_pos_y
        chassis_position['agv_pos_z'] = self._chassis_position.agv_pos_z
        chassis_position['agv_angle'] = self._chassis_position.agv_angle
        chassis_position['odom_x'] = self._chassis_position.odom_x
        chassis_position['odom_y'] = self._chassis_position.odom_y
        chassis_position['odom_z'] = self._chassis_position.odom_z
        chassis_position['odom_angle'] = self._chassis_position.odom_angle
        chassis_position['linear_speed'] = self._chassis_position.linear_speed
        chassis_position['angular_speed'] = self._chassis_position.angular_speed
        chassis_position['acc_x'] = self._chassis_position.acc_x
        chassis_position['acc_y'] = self._chassis_position.acc_y
        chassis_position['acc_z'] = self._chassis_position.acc_z
        chassis_position['gyro_x'] = self._chassis_position.gyro_x
        chassis_position['gyro_y'] = self._chassis_position.gyro_y
        chassis_position['gyro_z'] = self._chassis_position.gyro_z
        chassis_position['roll'] = self._chassis_position.roll
        chassis_position['pitch'] = self._chassis_position.pitch
        chassis_position['yaw'] = self._chassis_position.yaw
        chassis_position['motor_states'] = []
        for motor_state in self._chassis_position.motor_states:
            temp = {}
            temp['id'] = motor_state.id
            temp['enable'] = motor_state.enable
            temp['position'] = motor_state.position
            temp['velocity'] = motor_state.velocity
            temp['effort'] = motor_state.effort
            temp['current'] = motor_state.current
            temp['voltage'] = motor_state.voltage
            temp['temperature'] = motor_state.temperature
            temp['status'] = motor_state.status
            temp['err_code'] = motor_state.err_code
            chassis_position['motor_states'].append(temp)
        
        chassis_position['agv_task_state'] = {}
        if self._chassis_position.agv_task_state:
            chassis_position['agv_task_state']['task_uuid'] = self._chassis_position.agv_task_state.task_uuid
            chassis_position['agv_task_state']['task_reqid'] = self._chassis_position.agv_task_state.task_reqid
            chassis_position['agv_task_state']['curr_station_idx'] = self._chassis_position.agv_task_state.curr_station_idx
            chassis_position['agv_task_state']['finish_state'] = self._chassis_position.agv_task_state.finish_state
        
        return chassis_position, self._chassis_position.header.stamp.sec * 1e9 + self._chassis_position.header.stamp.nanosec
    """
    message BatteryStatus
{

  optional std_msgs.msg.pb.Header header      = 242399333;

  //单位: %, 0~100 @TODO: 和供应商统一
  optional float                  energy      = 387026206;

  //单位: V
  optional float                  voltage     = 228124592;

  //单位: A
  optional float                  current     = 485707626;

  //单位: Ah
  optional float                  capacity    = 367577322;

  //单位: ℃
  optional float                  temperature = 508445154;

  //0: unknown, 1: charging, 2: discharging, 3: not charging, 4: full, 5: empty
  optional uint32                 status      = 453014720;
}
    """
    def get_chassis_battery_status_callback(self, msg):
        self._chassis_battery_status.header.stamp.sec = msg.header.stamp.sec
        self._chassis_battery_status.header.stamp.nanosec = msg.header.stamp.nanosec
        self._chassis_battery_status.energy = msg.energy
        self._chassis_battery_status.voltage = msg.voltage
        self._chassis_battery_status.current = msg.current
        self._chassis_battery_status.capacity = msg.capacity
        self._chassis_battery_status.temperature = msg.temperature
        self._chassis_battery_status.status = msg.status
    
    def get_chassis_battery_status(self):
        battery_status = {}
        battery_status['energy'] = self._chassis_battery_status.energy
        battery_status['voltage'] = self._chassis_battery_status.voltage
        battery_status['current'] = self._chassis_battery_status.current
        battery_status['capacity'] = self._chassis_battery_status.capacity
        battery_status['temperature'] = self._chassis_battery_status.temperature
        battery_status['status'] = self._chassis_battery_status.status
        return battery_status, self._chassis_battery_status.header.stamp.sec * 1e9 + self._chassis_battery_status.header.stamp.nanosec
